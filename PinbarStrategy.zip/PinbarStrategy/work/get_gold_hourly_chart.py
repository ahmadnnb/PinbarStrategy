from __future__ import annotations

import json
import os
import ssl
from datetime import datetime, timezone
from pathlib import Path
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parents[1]
os.environ.setdefault("MPLCONFIGDIR", str(ROOT / "work" / ".matplotlib"))

import matplotlib.dates as mdates
import matplotlib.pyplot as plt
import pandas as pd


OUTPUTS = ROOT / "outputs"
OUTPUTS.mkdir(exist_ok=True)

SYMBOL = "GLD"
URL = (
    "https://query1.finance.yahoo.com/v8/finance/chart/"
    f"{SYMBOL}?range=60d&interval=1h&includePrePost=false"
)


def fetch_chart_data() -> dict:
    request = Request(
        URL,
        headers={
            "User-Agent": (
                "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/125.0 Safari/537.36"
            )
        },
    )
    try:
        import certifi

        context = ssl.create_default_context(cafile=certifi.where())
    except Exception:
        context = ssl._create_unverified_context()

    try:
        response = urlopen(request, timeout=30, context=context)
    except ssl.SSLCertVerificationError:
        response = urlopen(request, timeout=30, context=ssl._create_unverified_context())

    with response:
        return json.loads(response.read().decode("utf-8"))


def parse_ohlc(payload: dict) -> pd.DataFrame:
    result = payload["chart"]["result"][0]
    timestamps = result["timestamp"]
    quote = result["indicators"]["quote"][0]

    df = pd.DataFrame(
        {
            "datetime_utc": pd.to_datetime(timestamps, unit="s", utc=True),
            "open": quote["open"],
            "high": quote["high"],
            "low": quote["low"],
            "close": quote["close"],
            "volume": quote["volume"],
        }
    )
    df = df.dropna(subset=["open", "high", "low", "close"]).tail(200).reset_index(drop=True)
    df["datetime_new_york"] = df["datetime_utc"].dt.tz_convert("America/New_York")
    return df[
        [
            "datetime_utc",
            "datetime_new_york",
            "open",
            "high",
            "low",
            "close",
            "volume",
        ]
    ]


def plot_chart(df: pd.DataFrame) -> Path:
    times = df["datetime_new_york"].dt.tz_localize(None)
    fig, ax = plt.subplots(figsize=(15, 7), dpi=150)
    ax.plot(times, df["close"], color="#1f5eff", linewidth=1.8, label="Close")
    ax.fill_between(
        mdates.date2num(times),
        df["low"].to_numpy(),
        df["high"].to_numpy(),
        color="#1f5eff",
        alpha=0.12,
        label="High-low range",
    )

    last = df.iloc[-1]
    last_time = last["datetime_new_york"].strftime("%Y-%m-%d %H:%M %Z")
    ax.scatter(times.iloc[-1], last["close"], color="#d7263d", s=36, zorder=5)
    ax.annotate(
        f"{last['close']:.2f}",
        (times.iloc[-1], last["close"]),
        xytext=(8, 0),
        textcoords="offset points",
        va="center",
        fontsize=9,
        color="#d7263d",
    )

    ax.set_title(f"{SYMBOL} Latest 200 Hourly Candles - Close with High/Low Range")
    ax.set_xlabel("Date/time, New York")
    ax.set_ylabel("Price, USD")
    ax.grid(True, linewidth=0.5, alpha=0.35)
    ax.legend(loc="upper left")
    ax.xaxis.set_major_locator(mdates.AutoDateLocator(minticks=7, maxticks=12))
    ax.xaxis.set_major_formatter(mdates.ConciseDateFormatter(ax.xaxis.get_major_locator()))
    fig.autofmt_xdate()
    fig.tight_layout()

    chart_path = OUTPUTS / "gld_latest_200_hourly_chart.png"
    fig.savefig(chart_path, bbox_inches="tight")
    plt.close(fig)

    metadata_path = OUTPUTS / "gld_latest_200_hourly_metadata.txt"
    metadata_path.write_text(
        "\n".join(
            [
                f"symbol={SYMBOL}",
                f"source={URL}",
                f"rows={len(df)}",
                f"first_candle_utc={df.iloc[0]['datetime_utc']}",
                f"last_candle_utc={last['datetime_utc']}",
                f"last_candle_new_york={last_time}",
                f"last_close={last['close']:.4f}",
                f"generated_utc={datetime.now(timezone.utc).isoformat()}",
            ]
        )
        + "\n",
        encoding="utf-8",
    )
    return chart_path


def main() -> None:
    payload = fetch_chart_data()
    df = parse_ohlc(payload)
    csv_path = OUTPUTS / "gld_latest_200_hourly_ohlc.csv"
    df.to_csv(csv_path, index=False)
    chart_path = plot_chart(df)
    print(f"wrote {csv_path}")
    print(f"wrote {chart_path}")
    print(df.tail(5).to_string(index=False))


if __name__ == "__main__":
    main()
