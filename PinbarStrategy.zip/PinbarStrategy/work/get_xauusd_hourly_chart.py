from __future__ import annotations

import lzma
import os
import ssl
import struct
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timedelta, timezone
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parents[1]
os.environ.setdefault("MPLCONFIGDIR", str(ROOT / "work" / ".matplotlib"))

import matplotlib.dates as mdates
import matplotlib.pyplot as plt
import pandas as pd


OUTPUTS = ROOT / "outputs"
OUTPUTS.mkdir(exist_ok=True)

INSTRUMENT = "XAUUSD"
NEEDED_BARS = 200
MAX_LOOKBACK_HOURS = 24 * 45
WORKERS = 16
FETCH_TIMEOUT_SECONDS = 8


def dukascopy_url(hour_start: datetime) -> str:
    # Dukascopy stores months as zero-based numbers.
    return (
        "https://datafeed.dukascopy.com/datafeed/"
        f"{INSTRUMENT}/{hour_start.year}/{hour_start.month - 1:02d}/"
        f"{hour_start.day:02d}/{hour_start.hour:02d}h_ticks.bi5"
    )


def fetch_hour_ticks(hour_start: datetime) -> pd.DataFrame | None:
    request = Request(
        dukascopy_url(hour_start),
        headers={"User-Agent": "Mozilla/5.0"},
    )
    try:
        with urlopen(
            request,
            timeout=FETCH_TIMEOUT_SECONDS,
            context=ssl._create_unverified_context(),
        ) as response:
            compressed = response.read()
    except (HTTPError, URLError, TimeoutError):
        return None

    if not compressed:
        return None

    try:
        raw = lzma.decompress(compressed)
    except lzma.LZMAError:
        return None

    rows = []
    for offset in range(0, len(raw), 20):
        chunk = raw[offset : offset + 20]
        if len(chunk) != 20:
            continue
        millisecond, ask_i, bid_i, ask_volume, bid_volume = struct.unpack(">IIIff", chunk)
        # XAUUSD is quoted to 3 decimals in Dukascopy's integer tick format.
        ask = ask_i / 1000
        bid = bid_i / 1000
        price = (ask + bid) / 2
        rows.append(
            {
                "datetime_utc": hour_start + timedelta(milliseconds=millisecond),
                "price": price,
                "volume": ask_volume + bid_volume,
            }
        )

    if not rows:
        return None
    return pd.DataFrame(rows)


def build_hourly_bars() -> pd.DataFrame:
    now = datetime.now(timezone.utc).replace(minute=0, second=0, microsecond=0)
    frames = []
    hours = [now - timedelta(hours=i) for i in range(1, MAX_LOOKBACK_HOURS + 1)]

    with ThreadPoolExecutor(max_workers=WORKERS) as executor:
        future_to_hour = {executor.submit(fetch_hour_ticks, hour): hour for hour in hours}
        for index, future in enumerate(as_completed(future_to_hour), start=1):
            ticks = future.result()
            if ticks is not None and not ticks.empty:
                frames.append(ticks)
            if index % 100 == 0:
                print(f"checked {index} hours, found {len(frames)} non-empty hours", flush=True)

    if not frames:
        raise RuntimeError("No Dukascopy tick data returned for XAUUSD.")

    ticks = pd.concat(frames, ignore_index=True).sort_values("datetime_utc")
    bars = (
        ticks.set_index("datetime_utc")
        .resample("1h")
        .agg(
            open=("price", "first"),
            high=("price", "max"),
            low=("price", "min"),
            close=("price", "last"),
            tick_volume=("volume", "sum"),
            ticks=("price", "size"),
        )
        .dropna(subset=["open", "high", "low", "close"])
        .tail(NEEDED_BARS)
        .reset_index()
    )
    bars["datetime_utc"] = pd.to_datetime(bars["datetime_utc"], utc=True)
    bars["datetime_new_york"] = bars["datetime_utc"].dt.tz_convert("America/New_York")
    return bars[
        [
            "datetime_utc",
            "datetime_new_york",
            "open",
            "high",
            "low",
            "close",
            "tick_volume",
            "ticks",
        ]
    ]


def plot_chart(df: pd.DataFrame) -> Path:
    times = df["datetime_utc"].dt.tz_localize(None)
    fig, ax = plt.subplots(figsize=(15, 7), dpi=150)
    ax.plot(times, df["close"], color="#0f5f64", linewidth=1.8, label="Close")
    ax.fill_between(
        mdates.date2num(times),
        df["low"].to_numpy(),
        df["high"].to_numpy(),
        color="#d49a00",
        alpha=0.22,
        label="High-low range",
    )

    last = df.iloc[-1]
    ax.scatter(times.iloc[-1], last["close"], color="#b00020", s=36, zorder=5)
    ax.annotate(
        f"{last['close']:.2f}",
        (times.iloc[-1], last["close"]),
        xytext=(8, 0),
        textcoords="offset points",
        va="center",
        fontsize=9,
        color="#b00020",
    )

    ax.set_title(f"{INSTRUMENT} Latest {len(df)} Hourly OHLC Bars")
    ax.set_xlabel("Date/time, UTC")
    ax.set_ylabel("Spot gold price, USD")
    ax.grid(True, linewidth=0.5, alpha=0.35)
    ax.legend(loc="upper left")
    ax.xaxis.set_major_locator(mdates.AutoDateLocator(minticks=7, maxticks=12))
    ax.xaxis.set_major_formatter(mdates.ConciseDateFormatter(ax.xaxis.get_major_locator()))
    fig.autofmt_xdate()
    fig.tight_layout()

    chart_path = OUTPUTS / "xauusd_latest_200_hourly_chart.png"
    fig.savefig(chart_path, bbox_inches="tight")
    plt.close(fig)
    return chart_path


def main() -> None:
    df = build_hourly_bars()
    csv_path = OUTPUTS / "xauusd_latest_200_hourly_ohlc.csv"
    chart_path = plot_chart(df)
    df.to_csv(csv_path, index=False)

    metadata_path = OUTPUTS / "xauusd_latest_200_hourly_metadata.txt"
    last = df.iloc[-1]
    metadata_path.write_text(
        "\n".join(
            [
                f"instrument={INSTRUMENT}",
                "source=https://datafeed.dukascopy.com/datafeed/",
                f"rows={len(df)}",
                f"first_candle_utc={df.iloc[0]['datetime_utc']}",
                f"last_candle_utc={last['datetime_utc']}",
                f"last_close={last['close']:.4f}",
                f"generated_utc={datetime.now(timezone.utc).isoformat()}",
            ]
        )
        + "\n",
        encoding="utf-8",
    )

    print(f"wrote {csv_path}")
    print(f"wrote {chart_path}")
    print(f"wrote {metadata_path}")
    print(df.tail(5).to_string(index=False))


if __name__ == "__main__":
    main()
