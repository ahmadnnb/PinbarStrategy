from __future__ import annotations

import csv
from pathlib import Path

import matplotlib.dates as mdates
import matplotlib.pyplot as plt
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
INPUT = ROOT / "outputs" / "xauusd_20y_daily_refreshed.csv"
SIGNALS_CSV = ROOT / "outputs" / "xauusd_reverse_pinbar_signals.csv"
CHART = ROOT / "outputs" / "xauusd_reverse_pinbar_signals_chart.png"
SUMMARY = ROOT / "outputs" / "xauusd_reverse_pinbar_signals_summary.txt"

LOOKBACKS = (17, 18, 19, 20, 21, 31, 32, 33, 34, 36, 37, 38, 39, 55, 56, 57, 58)
REVERSE_PINBAR_LEVEL_RATIO = 0.383
DOJI_BODY_RATIO = 0.383
REVERSE_DOJI_CONFIRMATION_CLOSE_RATIO = 0.45


def build_candidates(df: pd.DataFrame, index: int) -> list[dict[str, object]]:
    current = df.iloc[index]
    candidates: list[dict[str, object]] = [
        {
            "type": "single",
            "start_index": index,
            "open": current["Open"],
            "high": current["High"],
            "low": current["Low"],
            "close": current["Close"],
        }
    ]

    if index > 0:
        previous = df.iloc[index - 1]
        candidates.append(
            {
                "type": "previous+current",
                "start_index": index - 1,
                "open": previous["Open"],
                "high": max(previous["High"], current["High"]),
                "low": min(previous["Low"], current["Low"]),
                "close": current["Close"],
            }
        )

    if index < len(df) - 1:
        following = df.iloc[index + 1]
        candidates.append(
            {
                "type": "current+next",
                "start_index": index,
                "open": current["Open"],
                "high": max(current["High"], following["High"]),
                "low": min(current["Low"], following["Low"]),
                "close": following["Close"],
            }
        )
        current_range = current["High"] - current["Low"]
        following_range = following["High"] - following["Low"]
        is_doji = (
            current_range > 0
            and abs(current["Close"] - current["Open"])
            <= current_range * DOJI_BODY_RATIO
        )
        confirms_reverse_doji = (
            following_range > 0
            and following["Close"] - following["Open"] <= 0
            and following["Close"] - following["Low"]
            <= following_range * REVERSE_DOJI_CONFIRMATION_CLOSE_RATIO
        )
        if is_doji and confirms_reverse_doji:
            candidates.append(
                {
                    "type": "reverse-doji+next-confirmation",
                    "start_index": index,
                    "open": current["Open"],
                    "high": current["High"],
                    "low": current["Low"],
                    "close": current["Close"],
                    "is_reverse_doji_pattern": True,
                }
            )

    return candidates


def main() -> None:
    df = pd.read_csv(INPUT)
    df["Date"] = pd.to_datetime(df["Date"], utc=True).dt.tz_localize(None)
    df = df.sort_values("Date").reset_index(drop=True)

    signal_rows: list[dict[str, object]] = []
    pattern_dates: set[int] = set()

    for index in range(len(df)):
        current = df.iloc[index]
        qualifying_candidates: list[dict[str, object]] = []

        for candidate in build_candidates(df, index):
            candidate_range = candidate["high"] - candidate["low"]
            candidate_level = (
                candidate["low"] + candidate_range * REVERSE_PINBAR_LEVEL_RATIO
            )
            is_reverse_pattern = (
                candidate.get("is_reverse_doji_pattern", False)
                or (
                    candidate_range > 0
                    and candidate["open"] <= candidate_level
                    and candidate["close"] <= candidate_level
                )
            )
            if not is_reverse_pattern:
                continue

            pattern_dates.add(index)
            matches: list[tuple[int, str, float]] = []

            for lag in LOOKBACKS:
                prior_index = index - lag
                if prior_index <= 0 or prior_index >= len(df) - 1:
                    continue

                prior = df.iloc[prior_index]
                condition_1 = candidate["high"] >= prior["High"]
                condition_2 = (
                    candidate["open"] <= prior["High"]
                    and candidate["close"] <= prior["High"]
                )
                intermediate_highs = df.iloc[
                    prior_index + 1 : candidate["start_index"]
                ]["High"]
                condition_3 = intermediate_highs.le(prior["High"]).all()
                condition_4 = (
                    prior["High"] >= df.iloc[prior_index - 1]["High"]
                    and prior["High"] >= df.iloc[prior_index + 1]["High"]
                )

                if condition_1 and condition_2 and condition_3 and condition_4:
                    matches.append(
                        (
                            lag,
                            prior["Date"].strftime("%Y-%m-%d"),
                            float(prior["High"]),
                        )
                    )

            if matches:
                candidate["level"] = candidate_level
                candidate["matches"] = matches
                qualifying_candidates.append(candidate)

        if qualifying_candidates:
            all_matches = sorted(
                {
                    match
                    for candidate in qualifying_candidates
                    for match in candidate["matches"]
                }
            )
            signal_rows.append(
                {
                    "Date": current["Date"].strftime("%Y-%m-%d"),
                    "PatternTypes": ",".join(
                        candidate["type"] for candidate in qualifying_candidates
                    ),
                    "Open": qualifying_candidates[0]["open"],
                    "High": max(c["high"] for c in qualifying_candidates),
                    "Low": min(c["low"] for c in qualifying_candidates),
                    "Close": qualifying_candidates[0]["close"],
                    "ReversePinbarLevel": qualifying_candidates[0]["level"],
                    "MatchingLags": ",".join(str(match[0]) for match in all_matches),
                    "MatchingDates": ",".join(match[1] for match in all_matches),
                    "MatchingPriorHighs": ",".join(
                        f"{match[2]:.4f}" for match in all_matches
                    ),
                }
            )

    signals = pd.DataFrame(signal_rows)
    signals.to_csv(SIGNALS_CSV, index=False, quoting=csv.QUOTE_MINIMAL)

    fig, ax = plt.subplots(figsize=(18, 9))
    ax.plot(df["Date"], df["Close"], color="#172554", linewidth=1.15)
    if not signals.empty:
        ax.scatter(
            pd.to_datetime(signals["Date"]),
            signals["High"],
            marker="v",
            s=48,
            color="#dc2626",
            edgecolor="white",
            linewidth=0.5,
            zorder=3,
            label=f"Reverse pinbar signal ({len(signals)})",
        )
        ax.legend(loc="upper left")

    ax.set_title("XAU/USD Daily Reverse Pinbar Signals")
    ax.set_xlabel("Date")
    ax.set_ylabel("Price (USD)")
    ax.grid(True, color="#d1d5db", alpha=0.55, linewidth=0.7)
    ax.xaxis.set_major_locator(mdates.YearLocator(2))
    ax.xaxis.set_major_formatter(mdates.DateFormatter("%Y"))
    fig.tight_layout()
    fig.savefig(CHART, dpi=180, bbox_inches="tight")
    plt.close(fig)

    SUMMARY.write_text(
        "\n".join(
            [
                "XAU/USD daily reverse pinbar signal summary",
                f"Rows analyzed: {len(df)}",
                f"Pattern dates found: {len(pattern_dates)}",
                f"Signals found: {len(signals)}",
                "Reverse pinbar: Open and Close <= Low + 0.383 * (High - Low)",
                "Reverse doji: abs(Close - Open) <= 0.383 * (High - Low).",
                "Reverse doji confirmation: next-day Close <= Open and "
                "Close - Low <= 0.45 * (High - Low).",
                "The four reverse historical terms are applied to the doji candle.",
                "Term 1: reverse pinbar High >= lookback candle High",
                "Term 2: reverse pinbar Open and Close <= lookback candle High",
                "Term 3: every intervening High <= lookback candle High",
                "Term 4: lookback High >= previous and following trading-day Highs",
                f"Lookbacks: {', '.join(map(str, LOOKBACKS))}",
            ]
        )
        + "\n",
        encoding="utf-8",
    )

    print(f"Rows analyzed: {len(df)}")
    print(f"Pattern dates: {len(pattern_dates)}")
    print(f"Signals: {len(signals)}")
    print(SIGNALS_CSV)


if __name__ == "__main__":
    main()
