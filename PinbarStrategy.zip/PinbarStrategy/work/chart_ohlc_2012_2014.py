import argparse
from pathlib import Path

import matplotlib.dates as mdates
import matplotlib.pyplot as plt
import pandas as pd
from matplotlib.patches import Rectangle


ROOT = Path(__file__).resolve().parents[1]
OHLC_FILE = ROOT / "outputs" / "xauusd_20y_daily_refreshed.csv"
SIGNALS_FILE = ROOT / "outputs" / "xauusd_pinbar_signals.csv"
def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--start", default="2012-01-01")
    parser.add_argument("--end", default="2014-12-31")
    parser.add_argument(
        "--output",
        default=str(ROOT / "outputs" / "xauusd_ohlc_2012_2014_with_signals.png"),
    )
    parser.add_argument(
        "--signal-type",
        help="Only include signals whose PinbarTypes value contains this text.",
    )
    parser.add_argument("--signals-file", default=str(SIGNALS_FILE))
    parser.add_argument(
        "--marker-direction",
        choices=("up", "down"),
        default="up",
    )
    args = parser.parse_args()

    start = pd.Timestamp(args.start)
    end = pd.Timestamp(args.end)
    output_file = Path(args.output)

    ohlc = pd.read_csv(OHLC_FILE, parse_dates=["Date"])
    signals = pd.read_csv(args.signals_file, parse_dates=["Date"])
    if args.signal_type:
        signals = signals.loc[
            signals["PinbarTypes"].str.contains(args.signal_type, regex=False, na=False)
        ].copy()

    ohlc = ohlc.loc[ohlc["Date"].between(start, end)].copy()
    signals = signals.loc[signals["Date"].between(start, end)].copy()

    fig, ax = plt.subplots(figsize=(24, 11))
    candle_width = 0.72

    for candle in ohlc.itertuples(index=False):
        x = mdates.date2num(candle.Date)
        rising = candle.Close >= candle.Open
        color = "#15803d" if rising else "#dc2626"

        ax.vlines(x, candle.Low, candle.High, color=color, linewidth=0.7, zorder=1)

        body_low = min(candle.Open, candle.Close)
        body_height = abs(candle.Close - candle.Open)
        if body_height == 0:
            ax.hlines(
                candle.Open,
                x - candle_width / 2,
                x + candle_width / 2,
                color=color,
                linewidth=1.1,
                zorder=2,
            )
        else:
            ax.add_patch(
                Rectangle(
                    (x - candle_width / 2, body_low),
                    candle_width,
                    body_height,
                    facecolor=color,
                    edgecolor=color,
                    linewidth=0.5,
                    zorder=2,
                )
            )

    if not signals.empty:
        price_span = ohlc["High"].max() - ohlc["Low"].min()
        marker_y = (
            signals["Low"] - price_span * 0.018
            if args.marker_direction == "up"
            else signals["High"] + price_span * 0.018
        )
        ax.scatter(
            signals["Date"],
            marker_y,
            marker="^" if args.marker_direction == "up" else "v",
            s=100,
            color="#2563eb" if args.marker_direction == "up" else "#dc2626",
            edgecolor="white",
            linewidth=0.8,
            zorder=4,
            label=(
                f"{args.signal_type} ({len(signals)})"
                if args.signal_type
                else f"Strategy signal ({len(signals)})"
            ),
        )
        for signal, y in zip(signals.itertuples(index=False), marker_y):
            ax.annotate(
                signal.Date.strftime("%Y-%m-%d"),
                (signal.Date, y),
                xytext=(0, -13 if args.marker_direction == "up" else 13),
                textcoords="offset points",
                ha="center",
                va="top" if args.marker_direction == "up" else "bottom",
                fontsize=8,
                color="#1e3a8a" if args.marker_direction == "up" else "#991b1b",
                rotation=45,
            )

    title_prefix = (
        "XAU/USD Daily OHLC Candles with Confirmed Doji Signals "
        if args.signal_type == "doji+next-confirmation"
        else "XAU/USD Daily OHLC Candles with Strategy Signals "
    )
    ax.set_title(
        title_prefix + f"({start:%Y}-{end:%Y})",
        fontsize=17,
        pad=16,
    )
    ax.set_xlabel("Date")
    ax.set_ylabel("Price (USD)")
    ax.set_xlim(start, end + pd.Timedelta(days=1))
    if (end - start).days > 365 * 6:
        ax.xaxis.set_major_locator(mdates.YearLocator(2))
        ax.xaxis.set_major_formatter(mdates.DateFormatter("%Y"))
    else:
        ax.xaxis.set_major_locator(mdates.MonthLocator(interval=2))
        ax.xaxis.set_major_formatter(mdates.DateFormatter("%b\n%Y"))
    ax.grid(True, color="#d1d5db", alpha=0.55, linewidth=0.6)
    if not signals.empty:
        ax.legend(loc="upper right")

    fig.tight_layout()
    fig.savefig(output_file, dpi=200, bbox_inches="tight")
    plt.close(fig)

    print(f"Candles: {len(ohlc)}")
    print(f"Signals: {len(signals)}")
    print(signals[["Date", "MatchingLags", "MatchingDates"]].to_string(index=False))
    print(output_file)


if __name__ == "__main__":
    main()
