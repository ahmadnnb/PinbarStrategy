from __future__ import annotations

import subprocess
import sys
from pathlib import Path

import matplotlib.dates as mdates
import matplotlib.pyplot as plt
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
WORK = ROOT / "work"
OHLC_FILE = ROOT / "outputs" / "xauusd_20y_daily_refreshed.csv"
NORMAL_SIGNALS_FILE = ROOT / "outputs" / "xauusd_pinbar_signals.csv"
REVERSE_SIGNALS_FILE = ROOT / "outputs" / "xauusd_reverse_pinbar_signals.csv"
TRADES_FILE = ROOT / "outputs" / "xauusd_strategy_backtest_trades.csv"
SUMMARY_FILE = ROOT / "outputs" / "xauusd_strategy_backtest_summary.txt"
EQUITY_CHART = ROOT / "outputs" / "xauusd_strategy_backtest_equity.png"
RETURNS_FILE = ROOT / "outputs" / "xauusd_strategy_signal_returns.csv"

RISK_REWARD = 1.0
INITIAL_EQUITY_R = 0.0
RISK_PER_TRADE = 0.01


def run_scanner(script_name: str) -> None:
    subprocess.run(
        [sys.executable, str(WORK / script_name)],
        cwd=ROOT,
        check=True,
        stdout=subprocess.DEVNULL,
    )


def load_data() -> tuple[pd.DataFrame, pd.DataFrame]:
    run_scanner("pinbar_signals.py")
    run_scanner("reverse_pinbar_signals.py")

    ohlc = pd.read_csv(OHLC_FILE, parse_dates=["Date"]).sort_values("Date")
    ohlc["Date"] = ohlc["Date"].dt.normalize()
    normal = pd.read_csv(NORMAL_SIGNALS_FILE, parse_dates=["Date"])
    normal["Date"] = normal["Date"].dt.normalize()
    reverse = pd.read_csv(REVERSE_SIGNALS_FILE, parse_dates=["Date"])
    reverse["Date"] = reverse["Date"].dt.normalize()

    normal = normal.assign(Direction="long", Strategy="normal")
    reverse = reverse.assign(Direction="short", Strategy="reverse")
    signals = pd.concat([normal, reverse], ignore_index=True, sort=False)
    signals = signals.sort_values(["Date", "Strategy"]).reset_index(drop=True)
    return ohlc.reset_index(drop=True), signals


def build_trade(signal: pd.Series, ohlc: pd.DataFrame) -> dict[str, object] | None:
    signal_index = ohlc.index[ohlc["Date"].eq(signal["Date"])]
    if len(signal_index) == 0:
        return None

    entry_index = int(signal_index[0])
    if entry_index >= len(ohlc) - 1:
        return None

    direction = signal["Direction"]
    entry = float(signal["Close"])

    if direction == "long":
        stop = float(signal["Low"])
        risk = entry - stop
        target = entry + risk * RISK_REWARD
    else:
        stop = float(signal["High"])
        risk = stop - entry
        target = entry - risk * RISK_REWARD

    if risk <= 0:
        return {
            "SignalDate": signal["Date"],
            "Strategy": signal["Strategy"],
            "Direction": direction,
            "EntryDate": signal["Date"],
            "Entry": entry,
            "Stop": stop,
            "Target": target,
            "Risk": risk,
            "ExitDate": signal["Date"],
            "Exit": entry,
            "Result": "invalid-risk",
            "R": 0.0,
            "BarsHeld": 0,
        }

    for exit_index in range(entry_index + 1, len(ohlc)):
        candle = ohlc.iloc[exit_index]

        if direction == "long":
            hit_stop = candle["Low"] <= stop
            hit_target = candle["High"] >= target
            if hit_stop and hit_target:
                result = "loss"
                exit_price = stop
                r_value = -1.0
            elif hit_stop:
                result = "loss"
                exit_price = stop
                r_value = -1.0
            elif hit_target:
                result = "win"
                exit_price = target
                r_value = RISK_REWARD
            else:
                continue
        else:
            hit_stop = candle["High"] >= stop
            hit_target = candle["Low"] <= target
            if hit_stop and hit_target:
                result = "loss"
                exit_price = stop
                r_value = -1.0
            elif hit_stop:
                result = "loss"
                exit_price = stop
                r_value = -1.0
            elif hit_target:
                result = "win"
                exit_price = target
                r_value = RISK_REWARD
            else:
                continue

        return {
            "SignalDate": signal["Date"],
            "Strategy": signal["Strategy"],
            "Direction": direction,
            "EntryDate": signal["Date"],
            "Entry": entry,
            "Stop": stop,
            "Target": target,
            "Risk": risk,
            "ExitDate": candle["Date"],
            "Exit": float(exit_price),
            "Result": result,
            "R": r_value,
            "BarsHeld": exit_index - entry_index,
        }

    last = ohlc.iloc[-1]
    if direction == "long":
        open_r = (float(last["Close"]) - entry) / risk
    else:
        open_r = (entry - float(last["Close"])) / risk

    return {
        "SignalDate": signal["Date"],
        "Strategy": signal["Strategy"],
        "Direction": direction,
        "EntryDate": signal["Date"],
        "Entry": entry,
        "Stop": stop,
        "Target": target,
        "Risk": risk,
        "ExitDate": last["Date"],
        "Exit": float(last["Close"]),
        "Result": "open",
        "R": open_r,
        "BarsHeld": len(ohlc) - 1 - entry_index,
    }


def max_drawdown(equity: pd.Series) -> float:
    running_peak = equity.cummax()
    drawdown = equity - running_peak
    return float(drawdown.min())


def main() -> None:
    ohlc, signals = load_data()
    trades = [
        trade
        for _, signal in signals.iterrows()
        if (trade := build_trade(signal, ohlc)) is not None
    ]
    results = pd.DataFrame(trades).sort_values(["ExitDate", "SignalDate", "Strategy"])
    results = results.reset_index(drop=True)
    results["ReturnPct"] = results["R"] * RISK_PER_TRADE * 100
    results["CumulativeR"] = INITIAL_EQUITY_R + results["R"].cumsum()
    results["CumulativeReturnPct"] = results["CumulativeR"] * RISK_PER_TRADE * 100
    results["EquityCompounded"] = (1 + results["R"] * RISK_PER_TRADE).cumprod()
    results["CompoundedReturnPct"] = (results["EquityCompounded"] - 1) * 100
    results.to_csv(TRADES_FILE, index=False)
    results[
        [
            "SignalDate",
            "Strategy",
            "Direction",
            "Entry",
            "Stop",
            "Target",
            "ExitDate",
            "Exit",
            "Result",
            "R",
            "ReturnPct",
            "CumulativeR",
            "CumulativeReturnPct",
            "EquityCompounded",
            "CompoundedReturnPct",
        ]
    ].to_csv(RETURNS_FILE, index=False)

    closed = results.loc[results["Result"].isin(["win", "loss"])].copy()
    wins = int((closed["Result"] == "win").sum())
    losses = int((closed["Result"] == "loss").sum())
    win_rate = wins / len(closed) if len(closed) else 0.0

    equity_closed = INITIAL_EQUITY_R + closed["R"].cumsum()
    mdd = max_drawdown(equity_closed) if not equity_closed.empty else 0.0

    by_strategy = (
        closed.groupby("Strategy")["R"]
        .agg(Trades="count", TotalR="sum", AverageR="mean")
        .reset_index()
    )
    by_direction = (
        closed.groupby("Direction")["R"]
        .agg(Trades="count", TotalR="sum", AverageR="mean")
        .reset_index()
    )

    lines = [
        "XAU/USD strategy backtest summary",
        f"Data range: {ohlc['Date'].min():%Y-%m-%d} to {ohlc['Date'].max():%Y-%m-%d}",
        f"Signals tested: {len(signals)}",
        f"Trades generated: {len(results)}",
        f"Closed trades: {len(closed)}",
        f"Open trades at end: {(results['Result'] == 'open').sum()}",
        f"Wins: {wins}",
        f"Losses: {losses}",
        f"Win rate: {win_rate:.2%}",
        f"Total R, closed only: {closed['R'].sum():.2f}",
        f"Average R, closed only: {closed['R'].mean():.2f}",
        f"Max drawdown, closed equity R: {mdd:.2f}",
        "",
        "Assumptions",
        "Entry: signal candle Close.",
        "Normal/buy stop: signal Low.",
        "Reverse/sell stop: signal High.",
        "Target: 1R from entry.",
        f"Return conversion: 1R = {RISK_PER_TRADE:.2%} account risk per trade.",
        "Cumulative return is fixed-risk arithmetic return.",
        "Compounded return risks the same percentage of current equity each trade.",
        "If target and stop both touch in the same daily candle, stop is counted first.",
        "Multiple signals can create overlapping trades; each signal is tested independently.",
        "",
        "By strategy",
        by_strategy.to_string(index=False),
        "",
        "By direction",
        by_direction.to_string(index=False),
    ]
    SUMMARY_FILE.write_text("\n".join(lines) + "\n", encoding="utf-8")

    fig, ax = plt.subplots(figsize=(14, 7))
    plot_data = results.loc[results["Result"].isin(["win", "loss"])].copy()
    plot_data["ExitDate"] = pd.to_datetime(plot_data["ExitDate"])
    plot_data["EquityR"] = plot_data["R"].cumsum()
    ax.step(plot_data["ExitDate"], plot_data["EquityR"], where="post", color="#2563eb")
    ax.axhline(0, color="#9ca3af", linewidth=0.8)
    ax.set_title("XAU/USD Strategy Backtest Equity Curve (R)")
    ax.set_xlabel("Exit date")
    ax.set_ylabel("Cumulative R")
    ax.grid(True, color="#d1d5db", alpha=0.65, linewidth=0.7)
    ax.xaxis.set_major_locator(mdates.YearLocator(2))
    ax.xaxis.set_major_formatter(mdates.DateFormatter("%Y"))
    fig.tight_layout()
    fig.savefig(EQUITY_CHART, dpi=180, bbox_inches="tight")
    plt.close(fig)

    print("\n".join(lines))
    print(TRADES_FILE)
    print(RETURNS_FILE)
    print(SUMMARY_FILE)
    print(EQUITY_CHART)


if __name__ == "__main__":
    main()
