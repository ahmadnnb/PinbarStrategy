from __future__ import annotations

import json
import os
import ssl
from datetime import datetime, timedelta, timezone
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import quote
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parents[1]
os.environ.setdefault("MPLCONFIGDIR", str(ROOT / "work" / ".matplotlib"))

import matplotlib.dates as mdates
import matplotlib.pyplot as plt
import pandas as pd


OUTPUTS = ROOT / "outputs"
OUTPUTS.mkdir(exist_ok=True)

SYMBOL = "GC=F"
LABEL = "COMEX Gold Futures"
YEARS = 20


def unix_seconds(dt: datetime) -> int:
    return int(dt.timestamp())


def fetch_yahoo_chart(symbol: str, start: datetime, end: datetime) -> dict:
    encoded_symbol = quote(symbol, safe="")
    url = (
        "https://query1.finance.yahoo.com/v8/finance/chart/"
        f"{encoded_symbol}?period1={unix_seconds(start)}&period2={unix_seconds(end)}"
        "&interval=1d&events=history&includeAdjustedClose=true"
    )
    request = Request(url, headers={"User-Agent": "Mozilla/5.0"})
    try:
        try:
            import certifi

            context = ssl.create_default_context(cafile=certifi.where())
        except Exception:
            context = ssl.create_default_context()

        response = urlopen(request, timeout=30, context=context)
    except (ssl.SSLError, URLError):
        response = urlopen(
            request,
            timeout=30,
            context=ssl._create_unverified_context(),
        )
    except HTTPError as exc:
        raise RuntimeError(f"Yahoo Finance request failed with HTTP {exc.code}") from exc

    with response:
        return json.loads(response.read().decode("utf-8"))


def parse_ohlc(payload: dict) -> tuple[pd.DataFrame, dict]:
    result = payload["chart"]["result"][0]
    quote = result["indicators"]["quote"][0]
    adjclose = result["indicators"].get("adjclose", [{}])[0].get("adjclose")

    df = pd.DataFrame(
        {
            "date": pd.to_datetime(result["timestamp"], unit="s", utc=True).date,
            "open": quote["open"],
            "high": quote["high"],
            "low": quote["low"],
            "close": quote["close"],
            "volume": quote["volume"],
        }
    )
    if adjclose:
        df["adj_close"] = adjclose

    df = df.dropna(subset=["open", "high", "low", "close"]).reset_index(drop=True)
    return df, result["meta"]


def plot_chart(df: pd.DataFrame) -> Path:
    dates = pd.to_datetime(df["date"])
    fig, ax = plt.subplots(figsize=(16, 8), dpi=150)
    ax.plot(dates, df["close"], color="#0f5f64", linewidth=1.3, label="Daily close")
    ax.fill_between(
        mdates.date2num(dates),
        df["low"].to_numpy(),
        df["high"].to_numpy(),
        color="#d49a00",
        alpha=0.18,
        label="Daily high-low range",
    )

    last = df.iloc[-1]
    ax.scatter(dates.iloc[-1], last["close"], color="#b00020", s=34, zorder=5)
    ax.annotate(
        f"{last['close']:.2f}",
        (dates.iloc[-1], last["close"]),
        xytext=(8, 0),
        textcoords="offset points",
        va="center",
        fontsize=9,
        color="#b00020",
    )

    ax.set_title(f"{LABEL} ({SYMBOL}) - Last {YEARS} Years Daily Price")
    ax.set_xlabel("Date")
    ax.set_ylabel("Price, USD")
    ax.grid(True, linewidth=0.5, alpha=0.35)
    ax.legend(loc="upper left")
    ax.xaxis.set_major_locator(mdates.YearLocator(base=2))
    ax.xaxis.set_major_formatter(mdates.DateFormatter("%Y"))
    fig.tight_layout()

    chart_path = OUTPUTS / "gold_futures_20y_daily_chart.png"
    fig.savefig(chart_path, bbox_inches="tight")
    plt.close(fig)
    return chart_path


def main() -> None:
    end = datetime.now(timezone.utc) + timedelta(days=1)
    start = end - timedelta(days=365 * YEARS + 5)
    payload = fetch_yahoo_chart(SYMBOL, start, end)
    df, meta = parse_ohlc(payload)

    csv_path = OUTPUTS / "gold_futures_20y_daily_ohlc.csv"
    chart_path = plot_chart(df)
    metadata_path = OUTPUTS / "gold_futures_20y_daily_metadata.txt"

    df.to_csv(csv_path, index=False)
    metadata_path.write_text(
        "\n".join(
            [
                f"requested_symbol={SYMBOL}",
                f"instrument_label={LABEL}",
                "note=Yahoo spot XAUUSD aliases were unavailable from this environment; this file uses GC=F gold futures.",
                "source=https://query1.finance.yahoo.com/v8/finance/chart/GC%3DF",
                f"rows={len(df)}",
                f"first_date={df.iloc[0]['date']}",
                f"last_date={df.iloc[-1]['date']}",
                f"last_close={df.iloc[-1]['close']:.4f}",
                f"currency={meta.get('currency')}",
                f"exchange={meta.get('fullExchangeName')}",
                f"generated_utc={datetime.now(timezone.utc).isoformat()}",
            ]
        )
        + "\n",
        encoding="utf-8",
    )

    print(f"wrote {csv_path}")
    print(f"wrote {chart_path}")
    print(f"wrote {metadata_path}")
    print(df.head(3).to_string(index=False))
    print(df.tail(5).to_string(index=False))


if __name__ == "__main__":
    main()
