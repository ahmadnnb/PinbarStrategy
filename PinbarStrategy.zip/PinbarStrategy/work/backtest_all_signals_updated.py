from __future__ import annotations

import csv
import importlib.util
from pathlib import Path

import pandas as pd

SIGNAL_SCANNER_FILE = Path(__file__).resolve().parent / "all_signals_updated.py"
spec = importlib.util.spec_from_file_location("all_signals_updated", SIGNAL_SCANNER_FILE)
if spec is None or spec.loader is None:
    raise ImportError(f"Cannot load signal scanner from {SIGNAL_SCANNER_FILE}")
signal_scanner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(signal_scanner)


ROOT = Path(__file__).resolve().parents[1]
OHLC_FILE = ROOT / "outputs" / "xauusd_20y_daily_refreshed_updated.csv"
NORMAL_SIGNALS_FILE = ROOT / "outputs" / "xauusd_pinbar_signals_updated.csv"
REVERSE_SIGNALS_FILE = ROOT / "outputs" / "xauusd_reverse_pinbar_signals_updated.csv"
TRADES_FILE = ROOT / "outputs" / "xauusd_strategy_backtest_trades_updated.csv"
RETURNS_FILE = ROOT / "outputs" / "xauusd_strategy_signal_returns_updated.csv"
SUMMARY_FILE = ROOT / "outputs" / "xauusd_strategy_backtest_summary_updated.txt"

SINGLE_LOOKBACKS = (18, 19, 20, 32, 33, 37, 38, 56, 57, 75, 76)
DOUBLE_OR_DOJI_LOOKBACKS = (
    18,
    19,
    20,
    21,
    32,
    33,
    34,
    37,
    38,
    39,
    56,
    57,
    58,
    75,
    76,
    77,
)
PINBAR_LEVEL_RATIO = 0.618
REVERSE_PINBAR_LEVEL_RATIO = 0.382
DOJI_BODY_RATIO = 0.382
DOJI_CONFIRMATION_CLOSE_RATIO = 0.55
REVERSE_DOJI_CONFIRMATION_CLOSE_RATIO = 0.45
RISK_REWARD = 1.0
RISK_PER_TRADE = 0.01


def lookbacks_for_candidate(candidate: dict[str, object]) -> tuple[int, ...]:
    return (
        SINGLE_LOOKBACKS
        if candidate["type"] == "single"
        else DOUBLE_OR_DOJI_LOOKBACKS
    )


def load_ohlc() -> pd.DataFrame:
    df = pd.read_csv(OHLC_FILE, parse_dates=["Date"])
    return df.sort_values("Date").reset_index(drop=True)


def normal_candidates(df: pd.DataFrame, index: int) -> list[dict[str, object]]:
    current = df.iloc[index]
    candidates: list[dict[str, object]] = [
        {
            "type": "single",
            "start_index": index,
            "open": current["Open"],
            "high": current["High"],
            "low": current["Low"],
            "close": current["Close"],
        }
    ]

    if index > 0:
        previous = df.iloc[index - 1]
        candidates.append(
            {
                "type": "previous+current",
                "start_index": index,
                "open": previous["Open"],
                "high": max(previous["High"], current["High"]),
                "low": min(previous["Low"], current["Low"]),
                "close": current["Close"],
            }
        )

    if index < len(df) - 1:
        following = df.iloc[index + 1]
        candidates.append(
            {
                "type": "current+next",
                "start_index": index + 1,
                "open": current["Open"],
                "high": max(current["High"], following["High"]),
                "low": min(current["Low"], following["Low"]),
                "close": following["Close"],
            }
        )
        current_range = current["High"] - current["Low"]
        following_range = following["High"] - following["Low"]
        is_doji = (
            current_range > 0
            and abs(current["Close"] - current["Open"])
            <= current_range * DOJI_BODY_RATIO
        )
        confirms_doji = (
            following_range > 0
            and following["Close"] - following["Open"] >= 0
            and following["Close"] - following["Low"]
            >= following_range * DOJI_CONFIRMATION_CLOSE_RATIO
        )
        if is_doji and confirms_doji:
            candidates.append(
                {
                    "type": "doji+next-confirmation",
                    "start_index": index + 1,
                    "open": current["Open"],
                    "high": current["High"],
                    "low": current["Low"],
                    "close": current["Close"],
                    "is_doji_pattern": True,
                }
            )

    return candidates


def reverse_candidates(df: pd.DataFrame, index: int) -> list[dict[str, object]]:
    current = df.iloc[index]
    candidates: list[dict[str, object]] = [
        {
            "type": "single",
            "start_index": index,
            "open": current["Open"],
            "high": current["High"],
            "low": current["Low"],
            "close": current["Close"],
        }
    ]

    if index > 0:
        previous = df.iloc[index - 1]
        candidates.append(
            {
                "type": "previous+current",
                "start_index": index,
                "open": previous["Open"],
                "high": max(previous["High"], current["High"]),
                "low": min(previous["Low"], current["Low"]),
                "close": current["Close"],
            }
        )

    if index < len(df) - 1:
        following = df.iloc[index + 1]
        candidates.append(
            {
                "type": "current+next",
                "start_index": index + 1,
                "open": current["Open"],
                "high": max(current["High"], following["High"]),
                "low": min(current["Low"], following["Low"]),
                "close": following["Close"],
            }
        )
        current_range = current["High"] - current["Low"]
        following_range = following["High"] - following["Low"]
        is_doji = (
            current_range > 0
            and abs(current["Close"] - current["Open"])
            <= current_range * DOJI_BODY_RATIO
        )
        confirms_reverse_doji = (
            following_range > 0
            and following["Close"] - following["Open"] <= 0
            and following["Close"] - following["Low"]
            <= following_range * REVERSE_DOJI_CONFIRMATION_CLOSE_RATIO
        )
        if is_doji and confirms_reverse_doji:
            candidates.append(
                {
                    "type": "reverse-doji+next-confirmation",
                    "start_index": index + 1,
                    "open": current["Open"],
                    "high": current["High"],
                    "low": current["Low"],
                    "close": current["Close"],
                    "is_reverse_doji_pattern": True,
                }
            )

    return candidates


def scan_normal(df: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, object]] = []
    for index in range(len(df)):
        current = df.iloc[index]
        qualifying: list[dict[str, object]] = []
        for candidate in normal_candidates(df, index):
            candle_range = candidate["high"] - candidate["low"]
            level = candidate["low"] + candle_range * PINBAR_LEVEL_RATIO
            if not (
                candidate.get("is_doji_pattern", False)
                or (
                    candle_range > 0
                    and candidate["open"] >= level
                    and candidate["close"] >= level
                )
            ):
                continue

            matches: list[tuple[int, str, float]] = []
            for lag in lookbacks_for_candidate(candidate):
                prior_index = index - lag
                if prior_index <= 0 or prior_index >= len(df) - 1:
                    continue
                prior = df.iloc[prior_index]
                condition_1 = candidate["low"] <= prior["Low"]
                condition_2 = (
                    candidate["open"] >= prior["Low"]
                    and candidate["close"] >= prior["Low"]
                )
                intermediate_lows = df.iloc[
                    prior_index + 1 : candidate["start_index"]
                ]["Low"]
                condition_3 = intermediate_lows.ge(prior["Low"]).all()
                condition_4 = (
                    prior["Low"] <= df.iloc[prior_index - 1]["Low"]
                    and prior["Low"] <= df.iloc[prior_index + 1]["Low"]
                )
                if condition_1 and condition_2 and condition_3 and condition_4:
                    matches.append(
                        (lag, prior["Date"].strftime("%Y-%m-%d"), float(prior["Low"]))
                    )
            if matches:
                candidate["level"] = level
                candidate["matches"] = matches
                qualifying.append(candidate)

        if qualifying:
            all_matches = sorted({m for c in qualifying for m in c["matches"]})
            rows.append(
                {
                    "Date": current["Date"].strftime("%Y-%m-%d"),
                    "PinbarTypes": ",".join(c["type"] for c in qualifying),
                    "Open": qualifying[0]["open"],
                    "High": max(c["high"] for c in qualifying),
                    "Low": min(c["low"] for c in qualifying),
                    "Close": qualifying[0]["close"],
                    "PinbarLevel": qualifying[0]["level"],
                    "MatchingLags": ",".join(str(m[0]) for m in all_matches),
                    "MatchingDates": ",".join(m[1] for m in all_matches),
                    "MatchingPriorLows": ",".join(f"{m[2]:.4f}" for m in all_matches),
                }
            )
    return pd.DataFrame(rows)


def scan_reverse(df: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, object]] = []
    for index in range(len(df)):
        current = df.iloc[index]
        qualifying: list[dict[str, object]] = []
        for candidate in reverse_candidates(df, index):
            candle_range = candidate["high"] - candidate["low"]
            level = candidate["low"] + candle_range * REVERSE_PINBAR_LEVEL_RATIO
            if not (
                candidate.get("is_reverse_doji_pattern", False)
                or (
                    candle_range > 0
                    and candidate["open"] <= level
                    and candidate["close"] <= level
                )
            ):
                continue

            matches: list[tuple[int, str, float]] = []
            for lag in lookbacks_for_candidate(candidate):
                prior_index = index - lag
                if prior_index <= 0 or prior_index >= len(df) - 1:
                    continue
                prior = df.iloc[prior_index]
                condition_1 = candidate["high"] >= prior["High"]
                condition_2 = (
                    candidate["open"] <= prior["High"]
                    and candidate["close"] <= prior["High"]
                )
                intermediate_highs = df.iloc[
                    prior_index + 1 : candidate["start_index"]
                ]["High"]
                condition_3 = intermediate_highs.le(prior["High"]).all()
                condition_4 = (
                    prior["High"] >= df.iloc[prior_index - 1]["High"]
                    and prior["High"] >= df.iloc[prior_index + 1]["High"]
                )
                if condition_1 and condition_2 and condition_3 and condition_4:
                    matches.append(
                        (lag, prior["Date"].strftime("%Y-%m-%d"), float(prior["High"]))
                    )
            if matches:
                candidate["level"] = level
                candidate["matches"] = matches
                qualifying.append(candidate)

        if qualifying:
            all_matches = sorted({m for c in qualifying for m in c["matches"]})
            rows.append(
                {
                    "Date": current["Date"].strftime("%Y-%m-%d"),
                    "PatternTypes": ",".join(c["type"] for c in qualifying),
                    "Open": qualifying[0]["open"],
                    "High": max(c["high"] for c in qualifying),
                    "Low": min(c["low"] for c in qualifying),
                    "Close": qualifying[0]["close"],
                    "ReversePinbarLevel": qualifying[0]["level"],
                    "MatchingLags": ",".join(str(m[0]) for m in all_matches),
                    "MatchingDates": ",".join(m[1] for m in all_matches),
                    "MatchingPriorHighs": ",".join(f"{m[2]:.4f}" for m in all_matches),
                }
            )
    return pd.DataFrame(rows)


def build_trade(signal: pd.Series, ohlc: pd.DataFrame) -> dict[str, object] | None:
    match = ohlc.index[ohlc["Date"].eq(signal["Date"])]
    if len(match) == 0:
        return None
    entry_index = int(match[0])
    if entry_index >= len(ohlc) - 1:
        return None

    direction = signal["Direction"]
    entry = float(signal["Close"])
    if direction == "long":
        stop = float(signal["Low"])
        risk = entry - stop
        target = entry + risk * RISK_REWARD
    else:
        stop = float(signal["High"])
        risk = stop - entry
        target = entry - risk * RISK_REWARD

    if risk <= 0:
        return None

    for exit_index in range(entry_index + 1, len(ohlc)):
        candle = ohlc.iloc[exit_index]
        if direction == "long":
            hit_stop = candle["Low"] <= stop
            hit_target = candle["High"] >= target
        else:
            hit_stop = candle["High"] >= stop
            hit_target = candle["Low"] <= target

        if hit_stop and hit_target:
            result, exit_price, r_value = "loss", stop, -1.0
        elif hit_stop:
            result, exit_price, r_value = "loss", stop, -1.0
        elif hit_target:
            result, exit_price, r_value = "win", target, RISK_REWARD
        else:
            continue

        return {
            "SignalDate": signal["Date"],
            "Strategy": signal["Strategy"],
            "Direction": direction,
            "EntryDate": signal["Date"],
            "Entry": entry,
            "Stop": stop,
            "Target": target,
            "Risk": risk,
            "ExitDate": candle["Date"],
            "Exit": float(exit_price),
            "Result": result,
            "R": r_value,
            "BarsHeld": exit_index - entry_index,
        }

    return None


def max_drawdown(equity: pd.Series) -> float:
    return float((equity - equity.cummax()).min()) if not equity.empty else 0.0


def main() -> None:
    ohlc = signal_scanner.load_ohlc()
    ohlc["Date"] = ohlc["Date"].dt.normalize()

    signals = signal_scanner.scan_all_signals(ohlc)
    signal_scanner.write_legacy_signal_files(signals)
    signals.to_csv(signal_scanner.ALL_SIGNALS_FILE, index=False, quoting=csv.QUOTE_MINIMAL)
    signals["Date"] = pd.to_datetime(signals["Date"]).dt.normalize()
    signals["Strategy"] = signals["Side"].map(
        {"normal/buy": "normal", "reverse/sell": "reverse"}
    )
    normal = signals.loc[signals["Strategy"].eq("normal")].copy()
    reverse = signals.loc[signals["Strategy"].eq("reverse")].copy()
    signals = signals.sort_values(["Date", "Strategy"]).reset_index(drop=True)

    trades = [
        trade
        for _, signal in signals.iterrows()
        if (trade := build_trade(signal, ohlc)) is not None
    ]
    results = pd.DataFrame(trades).sort_values(["ExitDate", "SignalDate", "Strategy"])
    results = results.reset_index(drop=True)
    results["ReturnPct"] = results["R"] * RISK_PER_TRADE * 100
    results["CumulativeR"] = results["R"].cumsum()
    results["CumulativeReturnPct"] = results["CumulativeR"] * RISK_PER_TRADE * 100
    results["EquityCompounded"] = (1 + results["R"] * RISK_PER_TRADE).cumprod()
    results["CompoundedReturnPct"] = (results["EquityCompounded"] - 1) * 100
    results.to_csv(TRADES_FILE, index=False)
    results[
        [
            "SignalDate",
            "Strategy",
            "Direction",
            "Entry",
            "Stop",
            "Target",
            "ExitDate",
            "Exit",
            "Result",
            "R",
            "ReturnPct",
            "CumulativeR",
            "CumulativeReturnPct",
            "EquityCompounded",
            "CompoundedReturnPct",
        ]
    ].to_csv(RETURNS_FILE, index=False)

    closed = results.loc[results["Result"].isin(["win", "loss"])].copy()
    wins = int((closed["Result"] == "win").sum())
    losses = int((closed["Result"] == "loss").sum())
    win_rate = wins / len(closed) if len(closed) else 0.0
    by_strategy = (
        closed.groupby("Strategy")["R"]
        .agg(Trades="count", Wins=lambda x: int((x > 0).sum()), TotalR="sum", AverageR="mean")
        .reset_index()
    )
    by_direction = (
        closed.groupby("Direction")["R"]
        .agg(Trades="count", Wins=lambda x: int((x > 0).sum()), TotalR="sum", AverageR="mean")
        .reset_index()
    )
    final_compounded = (
        float(results["CompoundedReturnPct"].iloc[-1]) if not results.empty else 0.0
    )

    lines = [
        "XAU/USD updated all-signal backtest summary",
        f"Data range: {ohlc['Date'].min():%Y-%m-%d} to {ohlc['Date'].max():%Y-%m-%d}",
        f"Normal buy signals: {len(normal)}",
        f"Reverse sell signals: {len(reverse)}",
        f"Signals tested: {len(signals)}",
        f"Closed trades: {len(closed)}",
        f"Wins: {wins}",
        f"Losses: {losses}",
        f"Win rate: {win_rate:.2%}",
        f"Total R: {closed['R'].sum():.2f}",
        f"Cumulative return at 1R = 1%: {closed['R'].sum() * RISK_PER_TRADE * 100:.2f}%",
        f"Compounded return: {final_compounded:.2f}%",
        f"Average R: {closed['R'].mean():.2f}",
        f"Max drawdown R: {max_drawdown(closed['R'].cumsum()):.2f}",
        "",
        "Assumptions",
        "Entry: signal candle Close.",
        "Normal/buy stop: signal Low.",
        "Reverse/sell stop: signal High.",
        "Target: 1R from entry.",
        "If stop and target both touch in the same daily candle, stop is counted first.",
        "Multiple signals can create overlapping trades; each signal is tested independently.",
        "",
        "By strategy",
        by_strategy.to_string(index=False),
        "",
        "By direction",
        by_direction.to_string(index=False),
    ]
    SUMMARY_FILE.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("\n".join(lines))
    print(NORMAL_SIGNALS_FILE)
    print(REVERSE_SIGNALS_FILE)
    print(TRADES_FILE)
    print(RETURNS_FILE)
    print(SUMMARY_FILE)


if __name__ == "__main__":
    main()
