from __future__ import annotations

import csv
import io
import json
import ssl
import subprocess
import urllib.request
from urllib.parse import quote as url_quote
from pathlib import Path

import certifi
import matplotlib.dates as mdates
import matplotlib.pyplot as plt
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
YAHOO_SYMBOL = "XAUUSD=X"
XAUUSD_DAILY_URL = (
    "https://raw.githubusercontent.com/ejtraderLabs/historical-data/"
    "main/XAUUSD/XAUUSDd1.csv"
)
INPUT = ROOT / "outputs" / "xauusd_20y_daily_ohlc.csv"
REFRESHED_INPUT = ROOT / "outputs" / "xauusd_20y_daily_refreshed.csv"
SIGNALS_CSV = ROOT / "outputs" / "xauusd_pinbar_signals.csv"
CHART = ROOT / "outputs" / "xauusd_pinbar_signals_chart.png"
SUMMARY = ROOT / "outputs" / "xauusd_pinbar_signals_summary.txt"

LOOKBACKS = (17, 18, 19, 20, 21, 31, 32, 33, 34, 36, 37, 38, 39, 55, 56, 57, 58)
PINBAR_LEVEL_RATIO = 0.617
DOJI_BODY_RATIO = 0.383
DOJI_CONFIRMATION_CLOSE_RATIO = 0.55


def fetch_gold_daily() -> pd.DataFrame:
    response = subprocess.run(
        [
            "curl",
            "-L",
            "--retry",
            "3",
            "--max-time",
            "60",
            XAUUSD_DAILY_URL,
        ],
        check=True,
        capture_output=True,
        text=True,
    )
    data = pd.read_csv(io.StringIO(response.stdout))
    data = data.rename(
        columns={
            "Date": "Date",
            "open": "Open",
            "high": "High",
            "low": "Low",
            "close": "Close",
        }
    )
    data = data[["Date", "Open", "High", "Low", "Close"]].dropna()
    data["Date"] = pd.to_datetime(data["Date"])
    for column in ["Open", "High", "Low", "Close"]:
        data[column] = pd.to_numeric(data[column], errors="coerce")
    data = data.dropna()
    if data["Close"].median() > 10000:
        data[["Open", "High", "Low", "Close"]] = (
            data[["Open", "High", "Low", "Close"]] / 100
        )
    data.to_csv(REFRESHED_INPUT, index=False)
    data.to_csv(INPUT, index=False)
    return data


def find_column(columns: list[str], target: str) -> str:
    matches = [column for column in columns if column.strip().lower() == target]
    if not matches:
        raise ValueError(f"Missing required column: {target}")
    return matches[0]


def main() -> None:
    try:
        df = pd.read_csv(REFRESHED_INPUT)
    except (PermissionError, FileNotFoundError):
        try:
            df = pd.read_csv(INPUT)
        except (PermissionError, FileNotFoundError):
            df = fetch_gold_daily()
    date_col = find_column(df.columns.tolist(), "date")
    open_col = find_column(df.columns.tolist(), "open")
    high_col = find_column(df.columns.tolist(), "high")
    low_col = find_column(df.columns.tolist(), "low")
    close_col = find_column(df.columns.tolist(), "close")

    df = df.rename(
        columns={
            date_col: "Date",
            open_col: "Open",
            high_col: "High",
            low_col: "Low",
            close_col: "Close",
        }
    )
    df["Date"] = pd.to_datetime(df["Date"], utc=True).dt.tz_localize(None)
    df = df.sort_values("Date").reset_index(drop=True)

    signal_rows: list[dict[str, object]] = []
    pattern_dates: set[int] = set()

    for index in range(len(df)):
        current = df.iloc[index]
        candidates: list[dict[str, object]] = [
            {
                "type": "single",
                "start_index": index,
                "open": current["Open"],
                "high": current["High"],
                "low": current["Low"],
                "close": current["Close"],
            }
        ]
        if index > 0:
            previous = df.iloc[index - 1]
            candidates.append(
                {
                    "type": "previous+current",
                    "start_index": index - 1,
                    "open": previous["Open"],
                    "high": max(previous["High"], current["High"]),
                    "low": min(previous["Low"], current["Low"]),
                    "close": current["Close"],
                }
            )
        if index < len(df) - 1:
            following = df.iloc[index + 1]
            candidates.append(
                {
                    "type": "current+next",
                    "start_index": index,
                    "open": current["Open"],
                    "high": max(current["High"], following["High"]),
                    "low": min(current["Low"], following["Low"]),
                    "close": following["Close"],
                }
            )
            current_range = current["High"] - current["Low"]
            following_range = following["High"] - following["Low"]
            is_doji = (
                current_range > 0
                and abs(current["Close"] - current["Open"])
                <= current_range * DOJI_BODY_RATIO
            )
            confirms_doji = (
                following_range > 0
                and following["Close"] - following["Open"] >= 0
                and following["Close"] - following["Low"]
                >= following_range * DOJI_CONFIRMATION_CLOSE_RATIO
            )
            if is_doji and confirms_doji:
                candidates.append(
                    {
                        "type": "doji+next-confirmation",
                        "start_index": index,
                        "open": current["Open"],
                        "high": current["High"],
                        "low": current["Low"],
                        "close": current["Close"],
                        "is_doji_pattern": True,
                    }
                )

        qualifying_candidates: list[dict[str, object]] = []
        for candidate in candidates:
            candidate_range = candidate["high"] - candidate["low"]
            candidate_level = candidate["low"] + candidate_range * PINBAR_LEVEL_RATIO
            is_pinbar_pattern = (
                candidate.get("is_doji_pattern", False)
                or (
                    candidate_range > 0
                    and candidate["open"] >= candidate_level
                    and candidate["close"] >= candidate_level
                )
            )
            if not is_pinbar_pattern:
                continue

            pattern_dates.add(index)
            matches: list[tuple[int, str, float]] = []
            for lag in LOOKBACKS:
                prior_index = index - lag
                if prior_index <= 0 or prior_index >= len(df) - 1:
                    continue

                prior = df.iloc[prior_index]
                condition_1 = candidate["low"] <= prior["Low"]
                condition_2 = (
                    candidate["open"] >= prior["Low"]
                    and candidate["close"] >= prior["Low"]
                )
                intermediate_lows = df.iloc[
                    prior_index + 1 : candidate["start_index"]
                ]["Low"]
                condition_3 = intermediate_lows.ge(prior["Low"]).all()
                condition_4 = (
                    prior["Low"] <= df.iloc[prior_index - 1]["Low"]
                    and prior["Low"] <= df.iloc[prior_index + 1]["Low"]
                )
                if condition_1 and condition_2 and condition_3 and condition_4:
                    matches.append(
                        (
                            lag,
                            prior["Date"].strftime("%Y-%m-%d"),
                            float(prior["Low"]),
                        )
                    )

            if matches:
                candidate["level"] = candidate_level
                candidate["matches"] = matches
                qualifying_candidates.append(candidate)

        if qualifying_candidates:
            all_matches = sorted(
                {
                    match
                    for candidate in qualifying_candidates
                    for match in candidate["matches"]
                }
            )
            signal_rows.append(
                {
                    "Date": current["Date"].strftime("%Y-%m-%d"),
                    "PinbarTypes": ",".join(
                        candidate["type"] for candidate in qualifying_candidates
                    ),
                    "Open": qualifying_candidates[0]["open"],
                    "High": max(c["high"] for c in qualifying_candidates),
                    "Low": min(c["low"] for c in qualifying_candidates),
                    "Close": qualifying_candidates[0]["close"],
                    "PinbarLevel": qualifying_candidates[0]["level"],
                    "MatchingLags": ",".join(str(match[0]) for match in all_matches),
                    "MatchingDates": ",".join(match[1] for match in all_matches),
                    "MatchingPriorLows": ",".join(
                        f"{match[2]:.4f}" for match in all_matches
                    ),
                }
            )

    signals = pd.DataFrame(signal_rows)
    signals.to_csv(SIGNALS_CSV, index=False, quoting=csv.QUOTE_MINIMAL)

    fig, ax = plt.subplots(figsize=(18, 9))
    ax.plot(df["Date"], df["Close"], color="#172554", linewidth=1.15, label="Daily close")

    if not signals.empty:
        signal_dates = pd.to_datetime(signals["Date"])
        ax.scatter(
            signal_dates,
            signals["Low"],
            marker="^",
            s=42,
            color="#dc2626",
            edgecolor="white",
            linewidth=0.5,
            zorder=3,
            label=f"Strategy signal ({len(signals)})",
        )

    ax.set_title(
        "XAU/USD Daily Strategy Signals\n"
        "Single/two-day pinbars and confirmed dojis; all signal conditions applied",
        fontsize=15,
        pad=14,
    )
    ax.set_xlabel("Date")
    ax.set_ylabel("Price (USD)")
    ax.grid(True, color="#d1d5db", alpha=0.55, linewidth=0.7)
    ax.legend(loc="upper left")
    ax.xaxis.set_major_locator(mdates.YearLocator(2))
    ax.xaxis.set_major_formatter(mdates.DateFormatter("%Y"))
    fig.tight_layout()
    fig.savefig(CHART, dpi=180, bbox_inches="tight")
    plt.close(fig)

    date_range = f"{df['Date'].min():%Y-%m-%d} to {df['Date'].max():%Y-%m-%d}"
    SUMMARY.write_text(
        "\n".join(
            [
                "XAU/USD daily strategy signal summary",
                f"Data range: {date_range}",
                f"Rows analyzed: {len(df)}",
                f"Pattern dates found: {len(pattern_dates)}",
                f"Signals found: {len(signals)}",
                "Pinbar rule: Open and Close must both be greater than or equal to "
                f"Low + {PINBAR_LEVEL_RATIO} * (High - Low)",
                "Pinbar forms: single candle, previous+current, or current+next.",
                "Two-day OHLC: first-day Open, second-day Close, minimum Low, maximum High.",
                f"Doji rule: abs(Close - Open) <= {DOJI_BODY_RATIO} * (High - Low).",
                "Doji confirmation: next-day Close >= Open and "
                "Close - Low >= 0.55 * (High - Low).",
                "The four historical signal terms are applied to the doji candle.",
                f"Lookbacks: {', '.join(map(str, LOOKBACKS))}",
                "Signal aggregation: a pinbar is marked when any lookback satisfies all terms.",
                "Term 1: pattern Low <= lookback candle Low",
                "Term 2: pattern Open >= lookback Low and pattern Close >= lookback Low",
                "Term 3: every intervening candle Low >= lookback candle Low",
                "Term 4: lookback candle Low <= previous and following trading-day Lows",
            ]
        )
        + "\n",
        encoding="utf-8",
    )

    print(f"Rows analyzed: {len(df)}")
    print(f"Pattern dates: {len(pattern_dates)}")
    print(f"Signals: {len(signals)}")
    print(CHART)
    print(SIGNALS_CSV)


if __name__ == "__main__":
    main()
