from __future__ import annotations

import csv
import io
import subprocess
from pathlib import Path

import matplotlib.dates as mdates
import matplotlib.pyplot as plt
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
XAUUSD_DAILY_URL = (
    "https://raw.githubusercontent.com/ejtraderLabs/historical-data/"
    "main/XAUUSD/XAUUSDd1.csv"
)
INPUT = ROOT / "outputs" / "xauusd_20y_daily_ohlc_updated.csv"
REFRESHED_INPUT = ROOT / "outputs" / "xauusd_20y_daily_refreshed_updated.csv"
SIGNALS_CSV = ROOT / "outputs" / "xauusd_pinbar_signals_updated.csv"
CHART = ROOT / "outputs" / "xauusd_pinbar_signals_chart_updated.png"
SUMMARY = ROOT / "outputs" / "xauusd_pinbar_signals_summary_updated.txt"

SINGLE_LOOKBACKS = (18, 19, 20, 32, 33, 37, 38, 56, 57, 75, 76)
DOUBLE_OR_DOJI_LOOKBACKS = (
    18,
    19,
    20,
    21,
    32,
    33,
    34,
    37,
    38,
    39,
    56,
    57,
    58,
    75,
    76,
    77,
)
PINBAR_LEVEL_RATIO = 0.618
DOJI_BODY_RATIO = 0.382
DOJI_CONFIRMATION_CLOSE_RATIO = 0.55


def lookbacks_for_candidate(candidate: dict[str, object]) -> tuple[int, ...]:
    return (
        SINGLE_LOOKBACKS
        if candidate["type"] == "single"
        else DOUBLE_OR_DOJI_LOOKBACKS
    )


def fetch_xauusd_daily() -> pd.DataFrame:
    response = subprocess.run(
        [
            "curl",
            "-L",
            "--retry",
            "3",
            "--max-time",
            "60",
            XAUUSD_DAILY_URL,
        ],
        check=True,
        capture_output=True,
        text=True,
    )
    data = pd.read_csv(io.StringIO(response.stdout))
    data = data.rename(
        columns={
            "open": "Open",
            "high": "High",
            "low": "Low",
            "close": "Close",
        }
    )
    data = data[["Date", "Open", "High", "Low", "Close"]].dropna()
    data["Date"] = pd.to_datetime(data["Date"])
    for column in ["Open", "High", "Low", "Close"]:
        data[column] = pd.to_numeric(data[column], errors="coerce")
    data = data.dropna().sort_values("Date").reset_index(drop=True)
    if data["Close"].median() > 10000:
        data[["Open", "High", "Low", "Close"]] = (
            data[["Open", "High", "Low", "Close"]] / 100
        )
    data.to_csv(REFRESHED_INPUT, index=False)
    data.to_csv(INPUT, index=False)
    return data


def load_ohlc() -> pd.DataFrame:
    try:
        data = pd.read_csv(REFRESHED_INPUT)
    except (PermissionError, FileNotFoundError):
        data = fetch_xauusd_daily()

    data = data.rename(
        columns={
            "date": "Date",
            "open": "Open",
            "high": "High",
            "low": "Low",
            "close": "Close",
        }
    )
    data["Date"] = pd.to_datetime(data["Date"], utc=True).dt.tz_localize(None)
    data = data[["Date", "Open", "High", "Low", "Close"]].dropna()
    return data.sort_values("Date").reset_index(drop=True)


def build_candidates(df: pd.DataFrame, index: int) -> list[dict[str, object]]:
    current = df.iloc[index]
    candidates: list[dict[str, object]] = [
        {
            "type": "single",
            "start_index": index,
            "open": current["Open"],
            "high": current["High"],
            "low": current["Low"],
            "close": current["Close"],
        }
    ]

    if index > 0:
        previous = df.iloc[index - 1]
        candidates.append(
            {
                "type": "previous+current",
                "start_index": index,
                "open": previous["Open"],
                "high": max(previous["High"], current["High"]),
                "low": min(previous["Low"], current["Low"]),
                "close": current["Close"],
            }
        )

    if index < len(df) - 1:
        following = df.iloc[index + 1]
        candidates.append(
            {
                "type": "current+next",
                "start_index": index + 1,
                "open": current["Open"],
                "high": max(current["High"], following["High"]),
                "low": min(current["Low"], following["Low"]),
                "close": following["Close"],
            }
        )

        current_range = current["High"] - current["Low"]
        following_range = following["High"] - following["Low"]
        is_doji = (
            current_range > 0
            and abs(current["Close"] - current["Open"])
            <= current_range * DOJI_BODY_RATIO
        )
        confirms_doji = (
            following_range > 0
            and following["Close"] - following["Open"] >= 0
            and following["Close"] - following["Low"]
            >= following_range * DOJI_CONFIRMATION_CLOSE_RATIO
        )
        if is_doji and confirms_doji:
            candidates.append(
                {
                    "type": "doji+next-confirmation",
                    "start_index": index + 1,
                    "open": current["Open"],
                    "high": current["High"],
                    "low": current["Low"],
                    "close": current["Close"],
                    "is_doji_pattern": True,
                }
            )

    return candidates


def scan_signals(df: pd.DataFrame) -> tuple[pd.DataFrame, int]:
    signal_rows: list[dict[str, object]] = []
    pattern_dates: set[int] = set()

    for index in range(len(df)):
        current = df.iloc[index]
        qualifying_candidates: list[dict[str, object]] = []

        for candidate in build_candidates(df, index):
            candidate_range = candidate["high"] - candidate["low"]
            candidate_level = candidate["low"] + candidate_range * PINBAR_LEVEL_RATIO
            is_pinbar_pattern = (
                candidate.get("is_doji_pattern", False)
                or (
                    candidate_range > 0
                    and candidate["open"] >= candidate_level
                    and candidate["close"] >= candidate_level
                )
            )
            if not is_pinbar_pattern:
                continue

            pattern_dates.add(index)
            matches: list[tuple[int, str, float]] = []
            for lag in lookbacks_for_candidate(candidate):
                prior_index = index - lag
                if prior_index <= 0 or prior_index >= len(df) - 1:
                    continue

                prior = df.iloc[prior_index]
                condition_1 = candidate["low"] <= prior["Low"]
                condition_2 = (
                    candidate["open"] >= prior["Low"]
                    and candidate["close"] >= prior["Low"]
                )
                intermediate_lows = df.iloc[
                    prior_index + 1 : candidate["start_index"]
                ]["Low"]
                condition_3 = intermediate_lows.ge(prior["Low"]).all()
                condition_4 = (
                    prior["Low"] <= df.iloc[prior_index - 1]["Low"]
                    and prior["Low"] <= df.iloc[prior_index + 1]["Low"]
                )
                if condition_1 and condition_2 and condition_3 and condition_4:
                    matches.append(
                        (
                            lag,
                            prior["Date"].strftime("%Y-%m-%d"),
                            float(prior["Low"]),
                        )
                    )

            if matches:
                candidate["level"] = candidate_level
                candidate["matches"] = matches
                qualifying_candidates.append(candidate)

        if qualifying_candidates:
            all_matches = sorted(
                {
                    match
                    for candidate in qualifying_candidates
                    for match in candidate["matches"]
                }
            )
            signal_rows.append(
                {
                    "Date": current["Date"].strftime("%Y-%m-%d"),
                    "PinbarTypes": ",".join(
                        candidate["type"] for candidate in qualifying_candidates
                    ),
                    "Open": qualifying_candidates[0]["open"],
                    "High": max(c["high"] for c in qualifying_candidates),
                    "Low": min(c["low"] for c in qualifying_candidates),
                    "Close": qualifying_candidates[0]["close"],
                    "PinbarLevel": qualifying_candidates[0]["level"],
                    "MatchingLags": ",".join(str(match[0]) for match in all_matches),
                    "MatchingDates": ",".join(match[1] for match in all_matches),
                    "MatchingPriorLows": ",".join(
                        f"{match[2]:.4f}" for match in all_matches
                    ),
                }
            )

    return pd.DataFrame(signal_rows), len(pattern_dates)


def write_chart(df: pd.DataFrame, signals: pd.DataFrame) -> None:
    fig, ax = plt.subplots(figsize=(18, 9))
    ax.plot(df["Date"], df["Close"], color="#172554", linewidth=1.15, label="Daily close")
    if not signals.empty:
        ax.scatter(
            pd.to_datetime(signals["Date"]),
            signals["Low"],
            marker="^",
            s=42,
            color="#dc2626",
            edgecolor="white",
            linewidth=0.5,
            zorder=3,
            label=f"Strategy signal ({len(signals)})",
        )
    ax.set_title(
        "XAU/USD Daily Strategy Signals\n"
        "Single/two-day pinbars and confirmed dojis; all signal conditions applied",
        fontsize=15,
        pad=14,
    )
    ax.set_xlabel("Date")
    ax.set_ylabel("Price (USD)")
    ax.grid(True, color="#d1d5db", alpha=0.55, linewidth=0.7)
    ax.legend(loc="upper left")
    ax.xaxis.set_major_locator(mdates.YearLocator(2))
    ax.xaxis.set_major_formatter(mdates.DateFormatter("%Y"))
    fig.tight_layout()
    fig.savefig(CHART, dpi=180, bbox_inches="tight")
    plt.close(fig)


def main() -> None:
    df = load_ohlc()
    signals, pattern_date_count = scan_signals(df)
    signals.to_csv(SIGNALS_CSV, index=False, quoting=csv.QUOTE_MINIMAL)
    write_chart(df, signals)

    SUMMARY.write_text(
        "\n".join(
            [
                "XAU/USD daily strategy signal summary",
                f"Data range: {df['Date'].min():%Y-%m-%d} to {df['Date'].max():%Y-%m-%d}",
                f"Rows analyzed: {len(df)}",
                f"Pattern dates found: {pattern_date_count}",
                f"Signals found: {len(signals)}",
                "Pinbar rule: Open and Close must both be greater than or equal to "
                f"Low + {PINBAR_LEVEL_RATIO} * (High - Low)",
                "Pinbar forms: single candle, previous+current, or current+next.",
                "Two-day OHLC: first-day Open, second-day Close, minimum Low, maximum High.",
                f"Doji rule: abs(Close - Open) <= {DOJI_BODY_RATIO} * (High - Low).",
                "Doji confirmation: next-day Close >= Open and "
                f"Close - Low >= {DOJI_CONFIRMATION_CLOSE_RATIO} * (High - Low).",
                "Term 1: pinbar Low <= lookback candle Low",
                "Term 2: pinbar Open and Close >= lookback candle Low",
                "Term 3: every intervening Low >= lookback candle Low",
                "Term 4: lookback Low <= previous and following trading-day Lows",
                f"Single pinbar lookbacks: {', '.join(map(str, SINGLE_LOOKBACKS))}",
                "Double pinbar/doji lookbacks: "
                f"{', '.join(map(str, DOUBLE_OR_DOJI_LOOKBACKS))}",
            ]
        )
        + "\n",
        encoding="utf-8",
    )

    print(f"Rows analyzed: {len(df)}")
    print(f"Pattern dates: {pattern_date_count}")
    print(f"Signals: {len(signals)}")
    print(CHART)
    print(SIGNALS_CSV)


if __name__ == "__main__":
    main()
