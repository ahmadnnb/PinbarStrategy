from __future__ import annotations

import subprocess
import sys
from pathlib import Path

import matplotlib.dates as mdates
import matplotlib.pyplot as plt
import pandas as pd
from matplotlib.patches import Rectangle


ROOT = Path(__file__).resolve().parents[1]
WORK = ROOT / "work"
OHLC_FILE = ROOT / "outputs" / "xauusd_20y_daily_refreshed.csv"
NORMAL_SIGNALS_FILE = ROOT / "outputs" / "xauusd_pinbar_signals.csv"
REVERSE_SIGNALS_FILE = ROOT / "outputs" / "xauusd_reverse_pinbar_signals.csv"
OUTPUT_FILE = ROOT / "outputs" / "xauusd_ohlc_full_history_all_signals.png"


def run_scanner(script_name: str) -> None:
    subprocess.run(
        [sys.executable, str(WORK / script_name)],
        cwd=ROOT,
        check=True,
        stdout=subprocess.DEVNULL,
    )


def plot_candles(ax: plt.Axes, ohlc: pd.DataFrame) -> None:
    candle_width = 0.72

    for candle in ohlc.itertuples(index=False):
        x = mdates.date2num(candle.Date)
        rising = candle.Close >= candle.Open
        color = "#15803d" if rising else "#dc2626"

        ax.vlines(x, candle.Low, candle.High, color=color, linewidth=0.55, zorder=1)

        body_low = min(candle.Open, candle.Close)
        body_height = abs(candle.Close - candle.Open)
        if body_height == 0:
            ax.hlines(
                candle.Open,
                x - candle_width / 2,
                x + candle_width / 2,
                color=color,
                linewidth=0.9,
                zorder=2,
            )
            continue

        ax.add_patch(
            Rectangle(
                (x - candle_width / 2, body_low),
                candle_width,
                body_height,
                facecolor=color,
                edgecolor=color,
                linewidth=0.35,
                zorder=2,
            )
        )


def main() -> None:
    run_scanner("pinbar_signals.py")
    run_scanner("reverse_pinbar_signals.py")

    ohlc = pd.read_csv(OHLC_FILE, parse_dates=["Date"]).sort_values("Date")
    normal = pd.read_csv(NORMAL_SIGNALS_FILE, parse_dates=["Date"])
    reverse = pd.read_csv(REVERSE_SIGNALS_FILE, parse_dates=["Date"])

    fig, ax = plt.subplots(figsize=(28, 12))
    plot_candles(ax, ohlc)

    price_span = ohlc["High"].max() - ohlc["Low"].min()
    normal_y = normal["Low"] - price_span * 0.015
    reverse_y = reverse["High"] + price_span * 0.015

    if not normal.empty:
        ax.scatter(
            normal["Date"],
            normal_y,
            marker="^",
            s=92,
            color="#2563eb",
            edgecolor="white",
            linewidth=0.75,
            zorder=4,
            label=f"Normal/bullish signals ({len(normal)})",
        )

    if not reverse.empty:
        ax.scatter(
            reverse["Date"],
            reverse_y,
            marker="v",
            s=92,
            color="#f97316",
            edgecolor="white",
            linewidth=0.75,
            zorder=4,
            label=f"Reverse/bearish signals ({len(reverse)})",
        )

    overlap_dates = set(normal["Date"]).intersection(set(reverse["Date"]))
    if overlap_dates:
        overlap = ohlc.loc[ohlc["Date"].isin(overlap_dates)]
        ax.scatter(
            overlap["Date"],
            overlap["Close"],
            marker="o",
            s=42,
            color="#111827",
            edgecolor="white",
            linewidth=0.6,
            zorder=5,
            label=f"Same-day normal + reverse ({len(overlap_dates)})",
        )

    ax.set_title(
        "XAU/USD Daily OHLC - Normal and Reverse Strategy Signals",
        fontsize=18,
        pad=16,
    )
    ax.set_xlabel("Date")
    ax.set_ylabel("Price (USD)")
    ax.set_xlim(ohlc["Date"].min(), ohlc["Date"].max() + pd.Timedelta(days=1))
    ax.grid(True, color="#d1d5db", alpha=0.55, linewidth=0.6)
    ax.legend(loc="upper left")
    ax.xaxis.set_major_locator(mdates.YearLocator(2))
    ax.xaxis.set_major_formatter(mdates.DateFormatter("%Y"))

    fig.tight_layout()
    fig.savefig(OUTPUT_FILE, dpi=200, bbox_inches="tight")
    plt.close(fig)

    print(f"Candles: {len(ohlc)}")
    print(f"Normal signals: {len(normal)}")
    print(f"Reverse signals: {len(reverse)}")
    print(f"Same-day normal + reverse: {len(overlap_dates)}")
    print(OUTPUT_FILE)


if __name__ == "__main__":
    main()
