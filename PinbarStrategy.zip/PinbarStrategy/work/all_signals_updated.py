from __future__ import annotations

import csv
from pathlib import Path

import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
OHLC_FILE = ROOT / "outputs" / "xauusd_20y_daily_refreshed_updated.csv"
NORMAL_SIGNALS_FILE = ROOT / "outputs" / "xauusd_pinbar_signals_updated.csv"
REVERSE_SIGNALS_FILE = ROOT / "outputs" / "xauusd_reverse_pinbar_signals_updated.csv"
ALL_SIGNALS_FILE = ROOT / "outputs" / "xauusd_all_signals_updated.csv"
SUMMARY_FILE = ROOT / "outputs" / "xauusd_all_signals_summary_updated.txt"

SINGLE_LOOKBACKS = (18, 19, 20, 32, 33, 37, 38, 56, 57, 75, 76)
DOUBLE_OR_DOJI_LOOKBACKS = (
    18,
    19,
    20,
    21,
    32,
    33,
    34,
    37,
    38,
    39,
    56,
    57,
    58,
    75,
    76,
    77,
)

PINBAR_LEVEL_RATIO = 0.618
REVERSE_PINBAR_LEVEL_RATIO = 0.382
DOJI_BODY_RATIO = 0.382
DOJI_CONFIRMATION_CLOSE_RATIO = 0.55
REVERSE_DOJI_CONFIRMATION_CLOSE_RATIO = 0.45


def load_ohlc() -> pd.DataFrame:
    df = pd.read_csv(OHLC_FILE, parse_dates=["Date"])
    df["Date"] = df["Date"].dt.normalize()
    return df.sort_values("Date").reset_index(drop=True)


def lookbacks_for_candidate(candidate: dict[str, object]) -> tuple[int, ...]:
    return (
        SINGLE_LOOKBACKS
        if candidate["type"] == "single"
        else DOUBLE_OR_DOJI_LOOKBACKS
    )


def signal_type(raw_pattern: str) -> str:
    parts = [part.strip() for part in raw_pattern.split(",") if part.strip()]
    if any("doji" in part for part in parts):
        return "doji"
    if any("+" in part for part in parts):
        return "double pinbar"
    if "single" in parts:
        return "single pinbar"
    return "unknown"


def normal_candidates(df: pd.DataFrame, index: int) -> list[dict[str, object]]:
    current = df.iloc[index]
    candidates: list[dict[str, object]] = [
        {
            "type": "single",
            "start_index": index,
            "open": current["Open"],
            "high": current["High"],
            "low": current["Low"],
            "close": current["Close"],
        }
    ]

    if index > 0:
        previous = df.iloc[index - 1]
        candidates.append(
            {
                "type": "previous+current",
                "start_index": index,
                "open": previous["Open"],
                "high": max(previous["High"], current["High"]),
                "low": min(previous["Low"], current["Low"]),
                "close": current["Close"],
            }
        )

    if index < len(df) - 1:
        following = df.iloc[index + 1]
        candidates.append(
            {
                "type": "current+next",
                "start_index": index + 1,
                "open": current["Open"],
                "high": max(current["High"], following["High"]),
                "low": min(current["Low"], following["Low"]),
                "close": following["Close"],
            }
        )

        current_range = current["High"] - current["Low"]
        following_range = following["High"] - following["Low"]
        is_doji = (
            current_range > 0
            and abs(current["Close"] - current["Open"])
            <= current_range * DOJI_BODY_RATIO
        )
        confirms_doji = (
            following_range > 0
            and following["Close"] - following["Open"] >= 0
            and following["Close"] - following["Low"]
            >= following_range * DOJI_CONFIRMATION_CLOSE_RATIO
        )
        if is_doji and confirms_doji:
            candidates.append(
                {
                    "type": "doji+next-confirmation",
                    "start_index": index + 1,
                    "open": current["Open"],
                    "high": current["High"],
                    "low": current["Low"],
                    "close": current["Close"],
                    "is_doji_pattern": True,
                }
            )

    return candidates


def reverse_candidates(df: pd.DataFrame, index: int) -> list[dict[str, object]]:
    current = df.iloc[index]
    candidates: list[dict[str, object]] = [
        {
            "type": "single",
            "start_index": index,
            "open": current["Open"],
            "high": current["High"],
            "low": current["Low"],
            "close": current["Close"],
        }
    ]

    if index > 0:
        previous = df.iloc[index - 1]
        candidates.append(
            {
                "type": "previous+current",
                "start_index": index,
                "open": previous["Open"],
                "high": max(previous["High"], current["High"]),
                "low": min(previous["Low"], current["Low"]),
                "close": current["Close"],
            }
        )

    if index < len(df) - 1:
        following = df.iloc[index + 1]
        candidates.append(
            {
                "type": "current+next",
                "start_index": index + 1,
                "open": current["Open"],
                "high": max(current["High"], following["High"]),
                "low": min(current["Low"], following["Low"]),
                "close": following["Close"],
            }
        )

        current_range = current["High"] - current["Low"]
        following_range = following["High"] - following["Low"]
        is_doji = (
            current_range > 0
            and abs(current["Close"] - current["Open"])
            <= current_range * DOJI_BODY_RATIO
        )
        confirms_reverse_doji = (
            following_range > 0
            and following["Close"] - following["Open"] <= 0
            and following["Close"] - following["Low"]
            <= following_range * REVERSE_DOJI_CONFIRMATION_CLOSE_RATIO
        )
        if is_doji and confirms_reverse_doji:
            candidates.append(
                {
                    "type": "reverse-doji+next-confirmation",
                    "start_index": index + 1,
                    "open": current["Open"],
                    "high": current["High"],
                    "low": current["Low"],
                    "close": current["Close"],
                    "is_reverse_doji_pattern": True,
                }
            )

    return candidates


def scan_normal(df: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, object]] = []

    for index in range(len(df)):
        current = df.iloc[index]
        qualifying: list[dict[str, object]] = []

        for candidate in normal_candidates(df, index):
            candle_range = candidate["high"] - candidate["low"]
            level = candidate["low"] + candle_range * PINBAR_LEVEL_RATIO
            is_pattern = (
                candidate.get("is_doji_pattern", False)
                or (
                    candle_range > 0
                    and candidate["open"] >= level
                    and candidate["close"] >= level
                )
            )
            if not is_pattern:
                continue

            matches: list[tuple[int, str, float]] = []
            for lag in lookbacks_for_candidate(candidate):
                prior_index = index - lag
                if prior_index <= 0 or prior_index >= len(df) - 1:
                    continue

                prior = df.iloc[prior_index]
                intermediate_lows = df.iloc[
                    prior_index + 1 : candidate["start_index"]
                ]["Low"]
                condition_1 = candidate["low"] <= prior["Low"]
                condition_2 = (
                    candidate["open"] >= prior["Low"]
                    and candidate["close"] >= prior["Low"]
                )
                condition_3 = intermediate_lows.ge(prior["Low"]).all()
                condition_4 = (
                    prior["Low"] <= df.iloc[prior_index - 1]["Low"]
                    and prior["Low"] <= df.iloc[prior_index + 1]["Low"]
                )
                if condition_1 and condition_2 and condition_3 and condition_4:
                    matches.append(
                        (lag, prior["Date"].strftime("%Y-%m-%d"), float(prior["Low"]))
                    )

            if matches:
                candidate["level"] = level
                candidate["matches"] = matches
                qualifying.append(candidate)

        if qualifying:
            all_matches = sorted({m for c in qualifying for m in c["matches"]})
            pattern = ",".join(c["type"] for c in qualifying)
            rows.append(
                {
                    "Date": current["Date"].strftime("%Y-%m-%d"),
                    "Side": "normal/buy",
                    "Direction": "long",
                    "SignalType": signal_type(pattern),
                    "PatternTypes": pattern,
                    "Open": qualifying[0]["open"],
                    "High": max(c["high"] for c in qualifying),
                    "Low": min(c["low"] for c in qualifying),
                    "Close": qualifying[0]["close"],
                    "SignalLevel": qualifying[0]["level"],
                    "MatchingLags": ",".join(str(m[0]) for m in all_matches),
                    "MatchingDates": ",".join(m[1] for m in all_matches),
                    "MatchingPriorPrices": ",".join(
                        f"{m[2]:.4f}" for m in all_matches
                    ),
                    "PriorPriceType": "Low",
                }
            )

    return pd.DataFrame(rows)


def scan_reverse(df: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, object]] = []

    for index in range(len(df)):
        current = df.iloc[index]
        qualifying: list[dict[str, object]] = []

        for candidate in reverse_candidates(df, index):
            candle_range = candidate["high"] - candidate["low"]
            level = candidate["low"] + candle_range * REVERSE_PINBAR_LEVEL_RATIO
            is_pattern = (
                candidate.get("is_reverse_doji_pattern", False)
                or (
                    candle_range > 0
                    and candidate["open"] <= level
                    and candidate["close"] <= level
                )
            )
            if not is_pattern:
                continue

            matches: list[tuple[int, str, float]] = []
            for lag in lookbacks_for_candidate(candidate):
                prior_index = index - lag
                if prior_index <= 0 or prior_index >= len(df) - 1:
                    continue

                prior = df.iloc[prior_index]
                intermediate_highs = df.iloc[
                    prior_index + 1 : candidate["start_index"]
                ]["High"]
                condition_1 = candidate["high"] >= prior["High"]
                condition_2 = (
                    candidate["open"] <= prior["High"]
                    and candidate["close"] <= prior["High"]
                )
                condition_3 = intermediate_highs.le(prior["High"]).all()
                condition_4 = (
                    prior["High"] >= df.iloc[prior_index - 1]["High"]
                    and prior["High"] >= df.iloc[prior_index + 1]["High"]
                )
                if condition_1 and condition_2 and condition_3 and condition_4:
                    matches.append(
                        (lag, prior["Date"].strftime("%Y-%m-%d"), float(prior["High"]))
                    )

            if matches:
                candidate["level"] = level
                candidate["matches"] = matches
                qualifying.append(candidate)

        if qualifying:
            all_matches = sorted({m for c in qualifying for m in c["matches"]})
            pattern = ",".join(c["type"] for c in qualifying)
            rows.append(
                {
                    "Date": current["Date"].strftime("%Y-%m-%d"),
                    "Side": "reverse/sell",
                    "Direction": "short",
                    "SignalType": signal_type(pattern),
                    "PatternTypes": pattern,
                    "Open": qualifying[0]["open"],
                    "High": max(c["high"] for c in qualifying),
                    "Low": min(c["low"] for c in qualifying),
                    "Close": qualifying[0]["close"],
                    "SignalLevel": qualifying[0]["level"],
                    "MatchingLags": ",".join(str(m[0]) for m in all_matches),
                    "MatchingDates": ",".join(m[1] for m in all_matches),
                    "MatchingPriorPrices": ",".join(
                        f"{m[2]:.4f}" for m in all_matches
                    ),
                    "PriorPriceType": "High",
                }
            )

    return pd.DataFrame(rows)


def scan_all_signals(df: pd.DataFrame) -> pd.DataFrame:
    normal = scan_normal(df)
    reverse = scan_reverse(df)
    signals = pd.concat([normal, reverse], ignore_index=True, sort=False)
    if signals.empty:
        return signals
    signals["Date"] = pd.to_datetime(signals["Date"])
    signals = signals.sort_values(["Date", "Side"]).reset_index(drop=True)
    signals["Date"] = signals["Date"].dt.strftime("%Y-%m-%d")
    return signals


def write_legacy_signal_files(signals: pd.DataFrame) -> None:
    normal = signals.loc[signals["Side"].eq("normal/buy")].copy()
    reverse = signals.loc[signals["Side"].eq("reverse/sell")].copy()

    normal = normal.rename(
        columns={
            "PatternTypes": "PinbarTypes",
            "SignalLevel": "PinbarLevel",
            "MatchingPriorPrices": "MatchingPriorLows",
        }
    )
    normal[
        [
            "Date",
            "PinbarTypes",
            "Open",
            "High",
            "Low",
            "Close",
            "PinbarLevel",
            "MatchingLags",
            "MatchingDates",
            "MatchingPriorLows",
        ]
    ].to_csv(NORMAL_SIGNALS_FILE, index=False, quoting=csv.QUOTE_MINIMAL)

    reverse = reverse.rename(
        columns={
            "SignalLevel": "ReversePinbarLevel",
            "MatchingPriorPrices": "MatchingPriorHighs",
        }
    )
    reverse[
        [
            "Date",
            "PatternTypes",
            "Open",
            "High",
            "Low",
            "Close",
            "ReversePinbarLevel",
            "MatchingLags",
            "MatchingDates",
            "MatchingPriorHighs",
        ]
    ].to_csv(REVERSE_SIGNALS_FILE, index=False, quoting=csv.QUOTE_MINIMAL)


def main() -> None:
    df = load_ohlc()
    signals = scan_all_signals(df)
    signals.to_csv(ALL_SIGNALS_FILE, index=False, quoting=csv.QUOTE_MINIMAL)
    write_legacy_signal_files(signals)

    normal_count = int(signals["Side"].eq("normal/buy").sum()) if not signals.empty else 0
    reverse_count = (
        int(signals["Side"].eq("reverse/sell").sum()) if not signals.empty else 0
    )
    summary = [
        "XAU/USD all signals summary",
        f"Data range: {df['Date'].min():%Y-%m-%d} to {df['Date'].max():%Y-%m-%d}",
        f"Rows analyzed: {len(df)}",
        f"Normal buy signals: {normal_count}",
        f"Reverse sell signals: {reverse_count}",
        f"All signals: {len(signals)}",
        f"Single pinbar lookbacks: {', '.join(map(str, SINGLE_LOOKBACKS))}",
        "Double pinbar/doji lookbacks: "
        f"{', '.join(map(str, DOUBLE_OR_DOJI_LOOKBACKS))}",
        f"Normal pinbar level: {PINBAR_LEVEL_RATIO}",
        f"Reverse pinbar level: {REVERSE_PINBAR_LEVEL_RATIO}",
        f"Doji body ratio: {DOJI_BODY_RATIO}",
    ]
    SUMMARY_FILE.write_text("\n".join(summary) + "\n", encoding="utf-8")

    print("\n".join(summary))
    print(ALL_SIGNALS_FILE)
    print(NORMAL_SIGNALS_FILE)
    print(REVERSE_SIGNALS_FILE)


if __name__ == "__main__":
    main()
