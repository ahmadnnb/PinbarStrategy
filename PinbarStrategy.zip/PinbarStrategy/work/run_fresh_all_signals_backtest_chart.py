from __future__ import annotations

import csv
import html
from datetime import datetime
from pathlib import Path

import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
RAW_XAUUSD = Path("/private/tmp/xauusd_d1.csv")
OHLC_OUT = ROOT / "outputs" / "xauusd_ohlc_fresh.csv"
ALL_SIGNALS_OUT = ROOT / "outputs" / "xauusd_all_signals_fresh.csv"
TRADES_OUT = ROOT / "outputs" / "xauusd_backtest_trades_fresh.csv"
DETAILS_OUT = ROOT / "outputs" / "xauusd_signal_details_fresh.csv"
SUMMARY_OUT = ROOT / "outputs" / "xauusd_backtest_summary_fresh.txt"
CHART_OUT = ROOT / "outputs" / "xauusd_all_signals_chart_fresh.svg"

SINGLE_LOOKBACKS = (18, 19, 20, 32, 33, 37, 38, 56, 57, 75, 76)
DOUBLE_OR_DOJI_LOOKBACKS = (
    18,
    19,
    20,
    21,
    32,
    33,
    34,
    37,
    38,
    39,
    56,
    57,
    58,
    75,
    76,
    77,
)
PINBAR_LEVEL_RATIO = 0.618
REVERSE_PINBAR_LEVEL_RATIO = 0.382
DOJI_BODY_RATIO = 0.382
DOJI_CONFIRMATION_CLOSE_RATIO = 0.55
REVERSE_DOJI_CONFIRMATION_CLOSE_RATIO = 0.45
RISK_REWARD = 1.0
RISK_PER_TRADE = 0.01


def load_ohlc() -> pd.DataFrame:
    df = pd.read_csv(RAW_XAUUSD)
    df = df.rename(
        columns={"open": "Open", "high": "High", "low": "Low", "close": "Close"}
    )
    df = df[["Date", "Open", "High", "Low", "Close"]].dropna()
    df["Date"] = pd.to_datetime(df["Date"]).dt.normalize()
    for column in ["Open", "High", "Low", "Close"]:
        df[column] = pd.to_numeric(df[column], errors="coerce")
    df = df.dropna().sort_values("Date").reset_index(drop=True)
    if df["Close"].median() > 10000:
        df[["Open", "High", "Low", "Close"]] = df[
            ["Open", "High", "Low", "Close"]
        ] / 100
    df.to_csv(OHLC_OUT, index=False)
    return df


def lookbacks_for_candidate(candidate: dict[str, object]) -> tuple[int, ...]:
    return (
        SINGLE_LOOKBACKS
        if candidate["type"] == "single"
        else DOUBLE_OR_DOJI_LOOKBACKS
    )


def signal_type(pattern: str) -> str:
    parts = [part.strip() for part in pattern.split(",") if part.strip()]
    if any("doji" in part for part in parts):
        return "doji"
    if any("+" in part for part in parts):
        return "double pinbar"
    if "single" in parts:
        return "single pinbar"
    return "unknown"


def normal_candidates(df: pd.DataFrame, index: int) -> list[dict[str, object]]:
    current = df.iloc[index]
    candidates = [
        {
            "type": "single",
            "start_index": index,
            "open": current.Open,
            "high": current.High,
            "low": current.Low,
            "close": current.Close,
        }
    ]

    if index > 0:
        previous = df.iloc[index - 1]
        candidates.append(
            {
                "type": "previous+current",
                "start_index": index,
                "open": previous.Open,
                "high": max(previous.High, current.High),
                "low": min(previous.Low, current.Low),
                "close": current.Close,
            }
        )

    if index < len(df) - 1:
        following = df.iloc[index + 1]
        candidates.append(
            {
                "type": "current+next",
                "start_index": index + 1,
                "open": current.Open,
                "high": max(current.High, following.High),
                "low": min(current.Low, following.Low),
                "close": following.Close,
            }
        )
        current_range = current.High - current.Low
        following_range = following.High - following.Low
        is_doji = (
            current_range > 0
            and abs(current.Close - current.Open) <= current_range * DOJI_BODY_RATIO
        )
        confirms_doji = (
            following_range > 0
            and following.Close - following.Open >= 0
            and following.Close - following.Low
            >= following_range * DOJI_CONFIRMATION_CLOSE_RATIO
        )
        if is_doji and confirms_doji:
            candidates.append(
                {
                    "type": "doji+next-confirmation",
                    "start_index": index + 1,
                    "open": current.Open,
                    "high": current.High,
                    "low": current.Low,
                    "close": current.Close,
                    "is_doji_pattern": True,
                }
            )
    return candidates


def reverse_candidates(df: pd.DataFrame, index: int) -> list[dict[str, object]]:
    current = df.iloc[index]
    candidates = [
        {
            "type": "single",
            "start_index": index,
            "open": current.Open,
            "high": current.High,
            "low": current.Low,
            "close": current.Close,
        }
    ]

    if index > 0:
        previous = df.iloc[index - 1]
        candidates.append(
            {
                "type": "previous+current",
                "start_index": index,
                "open": previous.Open,
                "high": max(previous.High, current.High),
                "low": min(previous.Low, current.Low),
                "close": current.Close,
            }
        )

    if index < len(df) - 1:
        following = df.iloc[index + 1]
        candidates.append(
            {
                "type": "current+next",
                "start_index": index + 1,
                "open": current.Open,
                "high": max(current.High, following.High),
                "low": min(current.Low, following.Low),
                "close": following.Close,
            }
        )
        current_range = current.High - current.Low
        following_range = following.High - following.Low
        is_doji = (
            current_range > 0
            and abs(current.Close - current.Open) <= current_range * DOJI_BODY_RATIO
        )
        confirms_reverse_doji = (
            following_range > 0
            and following.Close - following.Open <= 0
            and following.Close - following.Low
            <= following_range * REVERSE_DOJI_CONFIRMATION_CLOSE_RATIO
        )
        if is_doji and confirms_reverse_doji:
            candidates.append(
                {
                    "type": "reverse-doji+next-confirmation",
                    "start_index": index + 1,
                    "open": current.Open,
                    "high": current.High,
                    "low": current.Low,
                    "close": current.Close,
                    "is_reverse_doji_pattern": True,
                }
            )
    return candidates


def scan_normal(df: pd.DataFrame) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    for index in range(len(df)):
        current = df.iloc[index]
        qualifying: list[dict[str, object]] = []
        for candidate in normal_candidates(df, index):
            candle_range = candidate["high"] - candidate["low"]
            level = candidate["low"] + candle_range * PINBAR_LEVEL_RATIO
            is_pattern = candidate.get("is_doji_pattern", False) or (
                candle_range > 0
                and candidate["open"] >= level
                and candidate["close"] >= level
            )
            if not is_pattern:
                continue

            matches: list[tuple[int, str, float]] = []
            for lag in lookbacks_for_candidate(candidate):
                prior_index = index - lag
                if prior_index <= 0 or prior_index >= len(df) - 1:
                    continue
                prior = df.iloc[prior_index]
                intermediate_lows = df.iloc[
                    prior_index + 1 : candidate["start_index"]
                ].Low
                conditions = (
                    candidate["low"] <= prior.Low,
                    candidate["open"] >= prior.Low and candidate["close"] >= prior.Low,
                    intermediate_lows.ge(prior.Low).all(),
                    prior.Low <= df.iloc[prior_index - 1].Low
                    and prior.Low <= df.iloc[prior_index + 1].Low,
                )
                if all(conditions):
                    matches.append((lag, prior.Date.strftime("%Y-%m-%d"), prior.Low))
            if matches:
                candidate["level"] = level
                candidate["matches"] = matches
                qualifying.append(candidate)

        if qualifying:
            all_matches = sorted({m for c in qualifying for m in c["matches"]})
            pattern = ",".join(c["type"] for c in qualifying)
            rows.append(
                {
                    "Date": current.Date.strftime("%Y-%m-%d"),
                    "Side": "normal/buy",
                    "Direction": "long",
                    "SignalType": signal_type(pattern),
                    "PatternTypes": pattern,
                    "Open": qualifying[0]["open"],
                    "High": max(c["high"] for c in qualifying),
                    "Low": min(c["low"] for c in qualifying),
                    "Close": qualifying[0]["close"],
                    "SignalLevel": qualifying[0]["level"],
                    "MatchingLags": ",".join(str(m[0]) for m in all_matches),
                    "MatchingDates": ",".join(m[1] for m in all_matches),
                    "MatchingPriorPrices": ",".join(f"{m[2]:.4f}" for m in all_matches),
                    "PriorPriceType": "Low",
                }
            )
    return rows


def scan_reverse(df: pd.DataFrame) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    for index in range(len(df)):
        current = df.iloc[index]
        qualifying: list[dict[str, object]] = []
        for candidate in reverse_candidates(df, index):
            candle_range = candidate["high"] - candidate["low"]
            level = candidate["low"] + candle_range * REVERSE_PINBAR_LEVEL_RATIO
            is_pattern = candidate.get("is_reverse_doji_pattern", False) or (
                candle_range > 0
                and candidate["open"] <= level
                and candidate["close"] <= level
            )
            if not is_pattern:
                continue

            matches: list[tuple[int, str, float]] = []
            for lag in lookbacks_for_candidate(candidate):
                prior_index = index - lag
                if prior_index <= 0 or prior_index >= len(df) - 1:
                    continue
                prior = df.iloc[prior_index]
                intermediate_highs = df.iloc[
                    prior_index + 1 : candidate["start_index"]
                ].High
                conditions = (
                    candidate["high"] >= prior.High,
                    candidate["open"] <= prior.High
                    and candidate["close"] <= prior.High,
                    intermediate_highs.le(prior.High).all(),
                    prior.High >= df.iloc[prior_index - 1].High
                    and prior.High >= df.iloc[prior_index + 1].High,
                )
                if all(conditions):
                    matches.append((lag, prior.Date.strftime("%Y-%m-%d"), prior.High))
            if matches:
                candidate["level"] = level
                candidate["matches"] = matches
                qualifying.append(candidate)

        if qualifying:
            all_matches = sorted({m for c in qualifying for m in c["matches"]})
            pattern = ",".join(c["type"] for c in qualifying)
            rows.append(
                {
                    "Date": current.Date.strftime("%Y-%m-%d"),
                    "Side": "reverse/sell",
                    "Direction": "short",
                    "SignalType": signal_type(pattern),
                    "PatternTypes": pattern,
                    "Open": qualifying[0]["open"],
                    "High": max(c["high"] for c in qualifying),
                    "Low": min(c["low"] for c in qualifying),
                    "Close": qualifying[0]["close"],
                    "SignalLevel": qualifying[0]["level"],
                    "MatchingLags": ",".join(str(m[0]) for m in all_matches),
                    "MatchingDates": ",".join(m[1] for m in all_matches),
                    "MatchingPriorPrices": ",".join(f"{m[2]:.4f}" for m in all_matches),
                    "PriorPriceType": "High",
                }
            )
    return rows


def build_trade(signal: pd.Series, ohlc: pd.DataFrame) -> dict[str, object] | None:
    match = ohlc.index[ohlc.Date.eq(pd.Timestamp(signal.Date))]
    if len(match) == 0:
        return None
    entry_index = int(match[0])
    if entry_index >= len(ohlc) - 1:
        return None

    direction = signal.Direction
    entry = float(signal.Close)
    if direction == "long":
        stop = float(signal.Low)
        risk = entry - stop
        target = entry + risk * RISK_REWARD
    else:
        stop = float(signal.High)
        risk = stop - entry
        target = entry - risk * RISK_REWARD
    if risk <= 0:
        return None

    for exit_index in range(entry_index + 1, len(ohlc)):
        candle = ohlc.iloc[exit_index]
        if direction == "long":
            hit_stop = candle.Low <= stop
            hit_target = candle.High >= target
        else:
            hit_stop = candle.High >= stop
            hit_target = candle.Low <= target

        if hit_stop and hit_target:
            result, exit_price, r_value = "loss", stop, -1.0
        elif hit_stop:
            result, exit_price, r_value = "loss", stop, -1.0
        elif hit_target:
            result, exit_price, r_value = "win", target, RISK_REWARD
        else:
            continue

        return {
            "SignalDate": signal.Date.strftime("%Y-%m-%d"),
            "Side": signal.Side,
            "Direction": direction,
            "SignalType": signal.SignalType,
            "PatternTypes": signal.PatternTypes,
            "MatchingLags": signal.MatchingLags,
            "MatchingDates": signal.MatchingDates,
            "MatchingPriorPrices": signal.MatchingPriorPrices,
            "Entry": entry,
            "Stop": stop,
            "Target": target,
            "Risk": risk,
            "ExitDate": candle.Date.strftime("%Y-%m-%d"),
            "Exit": float(exit_price),
            "Result": result,
            "R": r_value,
            "BarsHeld": exit_index - entry_index,
        }
    return None


def svg_chart(ohlc: pd.DataFrame, signals: pd.DataFrame, trades: pd.DataFrame) -> None:
    width, height = 1900, 980
    ml, mr, mt, mb = 80, 40, 50, 105
    plot_w, plot_h = width - ml - mr, height - mt - mb
    low = min(ohlc.Low.min(), signals.Low.min()) - 30
    high = max(ohlc.High.max(), signals.High.max()) + 30
    span = high - low

    def x_at(index: int) -> float:
        return ml + (index / (len(ohlc) - 1)) * plot_w

    def y_at(price: float) -> float:
        return mt + (high - price) / span * plot_h

    date_to_index = {row.Date.strftime("%Y-%m-%d"): i for i, row in ohlc.iterrows()}
    trade_lookup = {row.SignalDate: row for row in trades.itertuples(index=False)}
    parts = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">',
        "<style>"
        "text{font-family:Arial,sans-serif;font-size:12px;fill:#1f2937}"
        ".axis{stroke:#9ca3af;stroke-width:1}.grid{stroke:#e5e7eb;stroke-width:1}"
        ".up{stroke:#15803d;fill:#15803d}.down{stroke:#dc2626;fill:#dc2626}"
        ".buy{fill:#2563eb;stroke:white;stroke-width:1.2}.sell{fill:#f97316;stroke:white;stroke-width:1.2}"
        ".label{font-size:11px;font-weight:500}.tiny{font-size:10px;fill:#4b5563}"
        "</style>",
        "<rect width='100%' height='100%' fill='#ffffff'/>",
        "<text x='80' y='28' style='font-size:20px;font-weight:600'>XAU/USD OHLC with updated strategy signals</text>",
        "<text x='80' y='46' class='tiny'>Blue up markers = normal/buy, orange down markers = reverse/sell. Marker text: signal type, lookback, result.</text>",
    ]

    for tick in range(1100, 2101, 100):
        y = y_at(tick)
        parts.append(f"<line class='grid' x1='{ml}' x2='{width-mr}' y1='{y:.2f}' y2='{y:.2f}'/>")
        parts.append(f"<text x='{ml-10}' y='{y+4:.2f}' text-anchor='end'>{tick}</text>")

    for year in range(2013, 2023):
        idxs = ohlc.index[ohlc.Date.eq(pd.Timestamp(f"{year}-01-01"))]
        idx = int(idxs[0]) if len(idxs) else int(ohlc.index[ohlc.Date.dt.year.eq(year)][0])
        x = x_at(idx)
        parts.append(f"<line class='grid' x1='{x:.2f}' x2='{x:.2f}' y1='{mt}' y2='{height-mb}'/>")
        parts.append(f"<text x='{x:.2f}' y='{height-70}' text-anchor='middle'>{year}</text>")

    candle_w = max(0.45, plot_w / len(ohlc) * 0.58)
    for i, candle in ohlc.iterrows():
        x = x_at(i)
        cls = "up" if candle.Close >= candle.Open else "down"
        yh, yl = y_at(candle.High), y_at(candle.Low)
        yo, yc = y_at(candle.Open), y_at(candle.Close)
        body_y = min(yo, yc)
        body_h = max(abs(yc - yo), 0.6)
        parts.append(f"<line class='{cls}' x1='{x:.2f}' x2='{x:.2f}' y1='{yh:.2f}' y2='{yl:.2f}' stroke-width='0.6'/>")
        parts.append(f"<rect class='{cls}' x='{x-candle_w/2:.2f}' y='{body_y:.2f}' width='{candle_w:.2f}' height='{body_h:.2f}'/>")

    for _, signal in signals.iterrows():
        idx = date_to_index[signal.Date.strftime("%Y-%m-%d")]
        x = x_at(idx)
        trade = trade_lookup.get(signal.Date.strftime("%Y-%m-%d"))
        result = trade.Result if trade else ""
        r_value = int(trade.R) if trade else ""
        label_code = {"doji": "D", "single pinbar": "S", "double pinbar": "2"}.get(signal.SignalType, "?")
        lookback = str(signal.MatchingLags).split(",")[0]
        if signal.Side == "normal/buy":
            y = y_at(signal.Low) + 16
            points = f"{x:.2f},{y-14:.2f} {x-7:.2f},{y:.2f} {x+7:.2f},{y:.2f}"
            parts.append(f"<polygon class='buy' points='{points}'/>")
            text_y = y + 14
        else:
            y = y_at(signal.High) - 16
            points = f"{x:.2f},{y+14:.2f} {x-7:.2f},{y:.2f} {x+7:.2f},{y:.2f}"
            parts.append(f"<polygon class='sell' points='{points}'/>")
            text_y = y - 8
        details = (
            f"{signal.Date.strftime('%Y-%m-%d')} {signal.Side}; {signal.SignalType}; "
            f"{signal.PatternTypes}; lookback {signal.MatchingLags}; prior {signal.MatchingDates}; "
            f"entry {signal.Close:.2f}; result {result} {r_value}R"
        )
        parts.append(f"<title>{html.escape(details)}</title>")
        parts.append(
            f"<text class='label' x='{x:.2f}' y='{text_y:.2f}' text-anchor='middle'>{label_code}{lookback}/{result[:1].upper()}</text>"
        )

    parts.extend(
        [
            f"<line class='axis' x1='{ml}' x2='{width-mr}' y1='{height-mb}' y2='{height-mb}'/>",
            f"<line class='axis' x1='{ml}' x2='{ml}' y1='{mt}' y2='{height-mb}'/>",
            "<text x='90' y='930'>Legend: D = doji, S = single pinbar, 2 = double pinbar. W/L = win/loss.</text>",
            "</svg>",
        ]
    )
    CHART_OUT.write_text("\n".join(parts), encoding="utf-8")


def main() -> None:
    ohlc = load_ohlc()
    signals = pd.DataFrame(scan_normal(ohlc) + scan_reverse(ohlc))
    signals["Date"] = pd.to_datetime(signals["Date"]).dt.normalize()
    signals = signals.sort_values(["Date", "Side"]).reset_index(drop=True)
    signals.to_csv(ALL_SIGNALS_OUT, index=False, quoting=csv.QUOTE_MINIMAL)

    trades = [
        trade
        for _, signal in signals.iterrows()
        if (trade := build_trade(signal, ohlc)) is not None
    ]
    trades_df = pd.DataFrame(trades).sort_values(["ExitDate", "SignalDate", "Side"])
    trades_df = trades_df.reset_index(drop=True)
    trades_df["ReturnPct"] = trades_df["R"] * RISK_PER_TRADE * 100
    trades_df["CumulativeR"] = trades_df["R"].cumsum()
    trades_df["CumulativeReturnPct"] = trades_df["CumulativeR"] * RISK_PER_TRADE * 100
    trades_df["EquityCompounded"] = (1 + trades_df["R"] * RISK_PER_TRADE).cumprod()
    trades_df["CompoundedReturnPct"] = (trades_df["EquityCompounded"] - 1) * 100
    trades_df.to_csv(TRADES_OUT, index=False, quoting=csv.QUOTE_MINIMAL)

    signals_for_details = signals.copy()
    signals_for_details["DateKey"] = signals_for_details["Date"].dt.strftime("%Y-%m-%d")
    trades_for_details = trades_df.copy()
    trades_for_details["DateKey"] = trades_for_details["SignalDate"]
    details = signals_for_details.merge(
        trades_for_details[
            [
                "DateKey",
                "SignalDate",
                "Side",
                "Entry",
                "Stop",
                "Target",
                "ExitDate",
                "Exit",
                "Result",
                "R",
                "BarsHeld",
                "CumulativeR",
                "CompoundedReturnPct",
            ]
        ],
        left_on=["DateKey", "Side"],
        right_on=["DateKey", "Side"],
        how="left",
    )
    details.to_csv(DETAILS_OUT, index=False, quoting=csv.QUOTE_MINIMAL)
    svg_chart(ohlc, signals, trades_df)

    closed = trades_df.loc[trades_df.Result.isin(["win", "loss"])]
    wins = int((closed.Result == "win").sum())
    losses = int((closed.Result == "loss").sum())
    win_rate = wins / len(closed) if len(closed) else 0
    total_r = closed.R.sum()
    max_dd = (closed.R.cumsum() - closed.R.cumsum().cummax()).min()
    final_comp = trades_df.CompoundedReturnPct.iloc[-1] if len(trades_df) else 0
    by_side = closed.groupby("Side").R.agg(
        Trades="count", Wins=lambda s: int((s > 0).sum()), TotalR="sum", AverageR="mean"
    )

    lines = [
        "XAU/USD fresh all-signal backtest summary",
        f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        f"Data range: {ohlc.Date.min():%Y-%m-%d} to {ohlc.Date.max():%Y-%m-%d}",
        f"Normal buy signals: {int(signals.Side.eq('normal/buy').sum())}",
        f"Reverse sell signals: {int(signals.Side.eq('reverse/sell').sum())}",
        f"Signals tested: {len(signals)}",
        f"Closed trades: {len(closed)}",
        f"Wins: {wins}",
        f"Losses: {losses}",
        f"Win rate: {win_rate:.2%}",
        f"Total R: {total_r:.2f}",
        f"Cumulative return at 1R = 1%: {total_r * RISK_PER_TRADE * 100:.2f}%",
        f"Compounded return: {final_comp:.2f}%",
        f"Average R: {closed.R.mean():.2f}",
        f"Max drawdown R: {max_dd:.2f}",
        "",
        "By side",
        by_side.to_string(),
        "",
        "Assumptions",
        "Entry: signal candle Close.",
        "Normal/buy stop: signal Low.",
        "Reverse/sell stop: signal High.",
        "Target: 1R from entry.",
        "If stop and target both touch in the same daily candle, stop is counted first.",
        "Multiple signals can create overlapping trades; each signal is tested independently.",
    ]
    SUMMARY_OUT.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("\n".join(lines))
    print(ALL_SIGNALS_OUT)
    print(TRADES_OUT)
    print(DETAILS_OUT)
    print(CHART_OUT)


if __name__ == "__main__":
    main()
